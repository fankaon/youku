<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';
require_login();
$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>批量导入 - 后台</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/style.css">
<meta name="csrf" content="<?= h($csrf) ?>">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
<div class="ibox"><div class="ibox-content">

<ul class="nav nav-tabs">
  <li class="active"><a href="#t1" data-toggle="tab">批量导入</a></li>
  <li><a href="#t2" data-toggle="tab">单个添加</a></li>
</ul>
<div class="tab-content" style="padding-top:20px">

  <!-- 批量导入 -->
  <div class="tab-pane active in" id="t1">
    <p style="font-size:13px;color:#666">每行一条，格式：<code>邮箱,优酷密码,邮箱密码</code>（也支持中文逗号、分号、Tab 分隔）；TOKEN 导入时自动随机生成。</p>
    <textarea id="importText" class="form-control" rows="12" placeholder="abc@aliyun.com,ykpass,mailpass&#10;def@aliyun.com,ykpass,mailpass"></textarea>
    <div style="margin-top:12px">
      <button class="btn btn-primary" id="importBtn"><i class="fa fa-upload"></i> 开始导入</button>
    </div>
  </div>

  <!-- 单个添加 -->
  <div class="tab-pane" id="t2" style="max-width:480px">
    <div class="form-group"><label>账号(邮箱)</label><input type="text" id="mail" class="form-control"></div>
    <div class="form-group"><label>优酷密码</label><input type="text" id="yk_pwd" class="form-control"></div>
    <div class="form-group"><label>邮箱密码</label><input type="text" id="pwd" class="form-control"></div>
    <div class="form-group"><label>结束日期(可选)</label><input type="date" id="end_time" class="form-control"></div>
    <button class="btn btn-primary" id="addBtn">添加</button>
  </div>

</div>
</div></div>
</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/common.js"></script>
<script>
layui.use(['layer'], function () {
    var layer = layui.layer;

    $('#importBtn').on('click', function () {
        var text = $('#importText').val();
        if (!text || !text.trim()) { layer.msg('请粘贴要导入的数据', {icon: 2}); return; }
        var idx = layer.load(2);
        http.post('../ajax.php', {contents: 'mail', act: 'import', text: text}).then(function (res) {
            layer.close(idx);
            if (res.code === 1) { layer.msg(res.msg, {icon: 1, time: 1500}, function () { location.reload(); }); }
            else { layer.msg(res.msg, {icon: 2}); }
        }).catch(function () { layer.close(idx); layer.msg('请求异常', {icon: 2}); });
    });

    $('#addBtn').on('click', function () {
        http.post('../ajax.php', {
            contents: 'mail', act: 'add',
            mail: $('#mail').val(), yk_pwd: $('#yk_pwd').val(),
            pwd: $('#pwd').val(), end_time: $('#end_time').val()
        }).then(function (res) {
            if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
            else { layer.msg(res.msg, {icon: 2}); }
        });
    });
});
</script>
</body>
</html>
