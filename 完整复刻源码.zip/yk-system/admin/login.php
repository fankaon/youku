<?php
/**
 * 后台登录
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';

if (current_admin()) { header('Location: index.php'); exit; }

$err = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $u = trim((string)($_POST['username'] ?? ''));
    $p = (string)($_POST['password'] ?? '');
    $r = do_login($u, $p);
    if ($r['code'] === 1) { header('Location: index.php'); exit; }
    $err = $r['msg'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>后台登录</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<style>
  html,body { height:100%; background: #2f3a45; }
  .login-box { max-width: 360px; margin: 9% auto 0; background:#fff; border-radius:10px;
               padding: 34px 32px; box-shadow: 0 8px 30px rgba(0,0,0,.25); }
  .login-box h3 { text-align:center; margin-bottom:24px; color:#333; }
  .err { color:#c0392b; font-size:13px; margin-bottom:12px; }
  .form-control { margin-bottom:16px; height:42px; }
</style>
</head>
<body>
<div class="login-box">
  <h3>验证查询系统 · 后台</h3>
  <?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
  <form method="post">
    <input type="text" name="username" class="form-control" placeholder="用户名" autofocus required>
    <input type="password" name="password" class="form-control" placeholder="密码" required>
    <button type="submit" class="btn btn-primary btn-block" style="height:42px">登 录</button>
  </form>
</div>
</body>
</html>
