<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';
require_login();
$csrf = csrf_token();
$perms = q('SELECT * FROM permissions ORDER BY sort, id');
$tops = [];
foreach ($perms as $p) { if ((int)$p['pid'] === 0) { $tops[] = $p; } }
$kidsOf = function ($pid) use ($perms) {
    $o = [];
    foreach ($perms as $p) { if ((int)$p['pid'] === (int)$pid) { $o[] = $p; } }
    return $o;
};
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>角色管理 - 后台</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/style.css">
<meta name="csrf" content="<?= h($csrf) ?>">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
<div class="row">
  <div class="col-sm-4">
    <div class="ibox"><div class="ibox-content">
      <button class="btn btn-primary btn-sm" id="addRole" style="margin-bottom:12px"><i class="fa fa-plus"></i> 新增角色</button>
      <table class="table table-bordered table-hover">
        <thead><tr><th>ID</th><th>角色名称</th><th width="120">操作</th></tr></thead>
        <tbody id="roleList"></tbody>
      </table>
    </div></div>
  </div>
  <div class="col-sm-8">
    <div class="ibox"><div class="ibox-content">
      <h4 id="editTitle">新增 / 编辑角色</h4>
      <input type="hidden" id="rid">
      <div class="form-group" style="margin-top:14px"><label>角色名称</label>
        <input type="text" id="rname" class="form-control" style="max-width:300px"></div>
      <div class="form-group"><label>权限分配</label>
        <div style="border:1px solid #e5e5e5;border-radius:6px;padding:14px">
          <label class="checkbox-inline"><input type="checkbox" id="allPerm"> <strong>全部权限（超级管理员）</strong></label>
          <hr>
          <?php foreach ($tops as $top): $cs = $kidsOf((int)$top['id']); if (!$cs) continue; ?>
          <div style="margin-bottom:10px">
            <strong><?= h($top['name']) ?></strong>
            <div style="margin-left:18px;margin-top:4px">
              <?php foreach ($cs as $c): ?>
                <label class="checkbox-inline"><input type="checkbox" class="perm-cb" value="<?= (int)$c['id'] ?>"> <?= h($c['name']) ?></label>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <button class="btn btn-primary" id="saveRole">保存</button>
    </div></div>
  </div>
</div>
</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/common.js"></script>
<script>
layui.use(['layer'], function () {
    var layer = layui.layer;

    function loadRoles() {
        http.post('../ajax.php', {contents: 'rules', act: 'page'}).then(function (res) {
            var html = '';
            res.data.forEach(function (d) {
                html += '<tr><td>' + d.id + '</td><td>' + esc(d.name) + '</td>'
                    + '<td><button class="btn btn-primary btn-xs editRow" data-id="' + d.id + '">编辑</button> '
                    + '<button class="btn btn-danger btn-xs delRow" data-id="' + d.id + '">删除</button></td></tr>';
            });
            $('#roleList').html(html);
            $('.editRow').each(function () {
                $(this).data('rules', res.data.find(function (x) { return x.id == $(this).data('id'); }.bind(this)).rules);
            });
        });
    }

    function resetForm() {
        $('#rid').val(''); $('#rname').val('');
        $('#allPerm').prop('checked', false); $('.perm-cb').prop('checked', false);
    }

    $('#addRole').on('click', resetForm);

    $('#roleList').on('click', '.editRow', function () {
        var id = $(this).data('id');
        http.post('../ajax.php', {contents: 'rules', act: 'page'}).then(function (res) {
            var r = res.data.find(function (x) { return x.id == id; });
            $('#rid').val(r.id); $('#rname').val(r.name);
            $('.perm-cb').prop('checked', false);
            if (r.rules === '*') { $('#allPerm').prop('checked', true); }
            else { $('#allPerm').prop('checked', false);
                r.rules.split(',').forEach(function (pid) {
                    $('.perm-cb[value="' + parseInt(pid) + '"]').prop('checked', true);
                });
            }
        });
    });

    $('#roleList').on('click', '.delRow', function () {
        var id = $(this).data('id');
        layer.confirm('确定删除该角色？', function () {
            http.post('../ajax.php', {contents: 'rules', act: 'del', id: id}).then(function (res) {
                layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2}); loadRoles();
            });
        });
    });

    $('#allPerm').on('change', function () { $('.perm-cb').prop('disabled', this.checked); });

    $('#saveRole').on('click', function () {
        var rules;
        if ($('#allPerm').is(':checked')) { rules = '*'; }
        else {
            rules = $('.perm-cb:checked').map(function () { return this.value; }).get();
            if (!rules.length) { layer.msg('请至少选择一项权限，或勾选全部权限', {icon: 2}); return; }
        }
        var id = $('#rid').val(), payload = {
            contents: 'rules', name: $('#rname').val(), rules: rules
        };
        if (id) { payload.act = 'update'; payload.id = id; } else { payload.act = 'add'; }
        http.post('../ajax.php', payload).then(function (res) {
            layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2});
            if (res.code === 1) { resetForm(); loadRoles(); }
        });
    });

    loadRoles();
});
</script>
</body>
</html>
