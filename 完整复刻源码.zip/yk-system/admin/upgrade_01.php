<?php
/**
 * 一键升级：为「封禁卡密 + 卡密激活」功能补字段 / 补配置
 * 用法：上传到 admin/upgrade_01.php，浏览器访问一次，看到成功后【删除本文件】
 * 可重复执行，不会重复加列、不影响现有数据
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';

if (function_exists('require_login')) { require_login(); }
@set_time_limit(120);

$log = [];

/* 1) 补字段 */
$have = [];
foreach (q('SHOW COLUMNS FROM mail_accounts') as $c) {
    $have[strtolower((string)$c['Field'])] = true;
}
$adds = [
    'status'     => "ALTER TABLE mail_accounts ADD COLUMN status TINYINT NOT NULL DEFAULT 1 COMMENT '1正常 0封禁'",
    'activated'  => "ALTER TABLE mail_accounts ADD COLUMN activated TINYINT NOT NULL DEFAULT 0 COMMENT '0未激活 1已激活'",
    'start_time' => "ALTER TABLE mail_accounts ADD COLUMN start_time DATETIME NULL DEFAULT NULL COMMENT '激活时间'",
];
foreach ($adds as $col => $sql) {
    if (isset($have[$col])) {
        $log[] = "字段 {$col}：已存在，跳过";
    } else {
        db()->exec($sql);
        $log[] = "字段 {$col}：已添加 ✓";
    }
}

/* 2) 老账号视为“已激活”，激活时间取导入时间（仅处理未激活行） */
$n = db()->exec("UPDATE mail_accounts SET activated = 1,
        start_time = COALESCE(start_time, add_time) WHERE activated = 0");
$log[] = "历史账号已标记为已激活：{$n} 条（新同步/新导入的卡密默认未激活）";

/* 3) 补配置 */
$cfgs = ['activate_days' => '30', 'code_fresh_seconds' => '600'];
foreach ($cfgs as $name => $val) {
    if (one('SELECT id FROM config WHERE name = ?', [$name])) {
        $log[] = "配置 {$name}：已存在，跳过";
    } else {
        qi('INSERT INTO config (name, value) VALUES (?, ?)', [$name, $val]);
        $log[] = "配置 {$name}：已添加（{$val}）✓";
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>一键升级</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body style="padding:30px">
<div style="max-width:720px">
    <h3>升级完成</h3>
    <table class="table table-bordered">
    <?php foreach ($log as $l): ?>
        <tr><td style="color:#2b8a3e;font-family:monospace"><?= htmlspecialchars($l, ENT_QUOTES, 'UTF-8') ?></td></tr>
    <?php endforeach; ?>
    </table>
    <div class="alert alert-warning">
        请<b>立即删除本文件 admin/upgrade_01.php</b>，避免他人访问。<br><br>
        功能说明：<br>
        · 后台「账号列表」新增 <b>封禁 / 解封</b>（单条与批量），被封卡密前端无法使用；<br>
        · 前端新增 <b>激活页 activate.php</b>，买家输入卡密激活后开始计时；<br>
        · 激活有效期由配置 <b>activate_days</b> 决定（默认 30 天）；<br>
        · 验证码只显示<b>登录</b>验证码，改密 / 改绑不显示。
    </div>
    <a href="index.php" class="btn btn-primary">返回后台首页</a>
</div>
</body>
</html>
