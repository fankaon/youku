<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';
$me = require_login();
$csrf = csrf_token();
$roles = q('SELECT id,name FROM roles ORDER BY id');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>管理员管理 - 后台</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/style.css">
<meta name="csrf" content="<?= h($csrf) ?>">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
<div class="ibox"><div class="ibox-content">

  <button class="btn btn-primary btn-sm" id="addBtn" style="margin-bottom:14px"><i class="fa fa-plus"></i> 添加管理员</button>
  <table class="table table-bordered table-hover">
    <thead><tr><th>ID</th><th>用户名</th><th>角色</th><th>状态</th><th>最后登录</th><th>IP</th><th width="160">操作</th></tr></thead>
    <tbody id="list"></tbody>
  </table>

</div></div>
</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/common.js"></script>
<script>
layui.use(['layer'], function () {
    var layer = layui.layer;
    var roles = <?= json_encode($roles) ?>;
    var myId = <?= (int)$me['id'] ?>;

    function roleOpts(sel) {
        return roles.map(function (r) {
            return '<option value="' + r.id + '"' + (r.id == sel ? ' selected' : '') + '>' + esc(r.name) + '</option>';
        }).join('');
    }

    function load() {
        http.post('../ajax.php', {contents: 'manage', act: 'page'}).then(function (res) {
            var html = '';
            res.data.forEach(function (d) {
                html += '<tr><td>' + d.id + '</td><td>' + esc(d.username) + '</td>'
                    + '<td><select class="form-control input-sm roleSel" data-id="' + d.id + '" style="min-width:120px">' + roleOpts(d.role_id) + '</select></td>'
                    + '<td><select class="form-control input-sm statusSel" data-id="' + d.id + '" style="width:90px">'
                    + '<option value="1"' + (d.status == 1 ? ' selected' : '') + '">正常</option>'
                    + '<option value="0"' + (d.status == 0 ? ' selected' : '') + '">禁用</option></select></td>'
                    + '<td>' + (d.last_time || '') + '</td><td>' + esc(d.last_ip || '') + '</td>'
                    + '<td><button class="btn btn-warning btn-xs pwdRow" data-id="' + d.id + '">改密</button> '
                    + '<button class="btn btn-danger btn-xs delRow" data-id="' + d.id + '">删除</button></td></tr>';
            });
            $('#list').html(html);
        });
    }

    $('#addBtn').on('click', function () {
        var body = '<div style="padding:18px 22px 0">'
            + '<input type="text" id="nu" class="form-control" placeholder="用户名" style="margin-bottom:12px">'
            + '<input type="password" id="np" class="form-control" placeholder="密码(至少6位)" style="margin-bottom:12px">'
            + '<select id="nr" class="form-control">' + roleOpts(1) + '</select></div>';
        layer.open({type: 1, title: '添加管理员', area: ['360px', 'auto'], content: body,
            btn: ['确定', '取消'], yes: function (idx) {
                http.post('../ajax.php', {contents: 'manage', act: 'add',
                    username: $('#nu').val(), password: $('#np').val(), role_id: $('#nr').val()
                }).then(function (res) {
                    layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2});
                    if (res.code === 1) { layer.close(idx); load(); }
                });
            }});
    });

    $('#list').on('change', '.roleSel,.statusSel', function () {
        var id = $(this).data('id');
        http.post('../ajax.php', {contents: 'manage', act: 'update', id: id,
            role_id: $('.roleSel[data-id="' + id + '"]').val(),
            status: $('.statusSel[data-id="' + id + '"]').val()
        }).then(function (res) { layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2}); });
    });

    $('#list').on('click', '.pwdRow', function () {
        var id = $(this).data('id');
        var body = '<div style="padding:18px 22px 0"><input type="password" id="npp" class="form-control" placeholder="新密码(至少6位)"></div>';
        layer.open({type: 1, title: '修改密码', area: ['320px', 'auto'], content: body,
            btn: ['确定', '取消'], yes: function (idx) {
                http.post('../ajax.php', {contents: 'manage', act: 'update', id: id, password: $('#npp').val()
                }).then(function (res) {
                    layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2});
                    if (res.code === 1) { layer.close(idx); }
                });
            }});
    });

    $('#list').on('click', '.delRow', function () {
        var id = $(this).data('id');
        layer.confirm('确定删除该管理员？', function () {
            http.post('../ajax.php', {contents: 'manage', act: 'del', id: id}).then(function (res) {
                layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2}); load();
            });
        });
    });

    load();
});
</script>
</body>
</html>
