<?php
/**
 * 账号列表（修复版）
 * 修复：原页面分页组件初始 count=0，AJAX 拿到数据后未重新渲染分页，
 *       导致一直显示「共 0 条」、无法翻页；改为数据加载后按真实总数
 *       重新渲染分页（带防循环保护）。
 * 用法：上传覆盖 admin/mail.php
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';

if (function_exists('require_login')) { require_login(); }

/* CSRF：优先用框架函数；否则从会话读取/生成 */
$csrf = '';
if (function_exists('csrf_token')) {
    $csrf = csrf_token();
} else {
    foreach (['csrf', 'csrf_token', '_csrf', 'token'] as $k) {
        if (!empty($_SESSION[$k])) { $csrf = (string)$_SESSION[$k]; break; }
    }
    if ($csrf === '') {
        $csrf = bin2hex(random_bytes(16));
        $_SESSION['csrf'] = $csrf;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>账号列表 - 后台管理</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/layui.css">
<link rel="stylesheet" href="/css/style.css">
<meta name="csrf" content="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox">
        <div class="ibox-content">
            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-2" style="width:100px">
                        <a href="mail_add.php"><button class="btn btn-primary" type="button"><i class="fa fa-plus"></i> 添加</button></a>
                    </div>
                    <form class="form-search">
                        <div class="col-sm-4">
                            <div class="input-group">
                                <input type="text" id="key_v" class="form-control" placeholder="输入需查询的邮箱账号">
                                <span class="input-group-btn">
                                    <button type="button" id="search_id" class="btn btn-primary"><i class="fa fa-search"></i> 搜索</button>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="example-wrap">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <td colspan="9">
                            <button type="button" onclick="del_order()" class="btn btn-danger"><i class="fa fa-trash-o"></i> 批量删除</button>
                            <button type="button" onclick="del_expired()" class="btn btn-primary"><i class="fa fa-trash-o"></i> 一键删除到期</button>
                            <button type="button" onclick="execl_s()" class="btn btn-info"><i class="fa fa-share"></i> 导出选中excel</button>
                            <button type="button" onclick="up_time()" class="btn btn-warning"><i class="fa fa-clock-o"></i> 批量更新日期</button>
                            <button type="button" onclick="ban_batch(0)" class="btn btn-danger"><i class="fa fa-ban"></i> 批量封禁</button>
                            <button type="button" onclick="ban_batch(1)" class="btn btn-success"><i class="fa fa-unlock"></i> 批量解封</button>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:90px"><input type="checkbox" id="all" onclick="checkAll()">&nbsp;全选</td>
                        <th>TOKEN</th>
                        <th>账号</th>
                        <th>优酷密码</th>
                        <th>邮箱密码</th>
                        <th>创建时间</th>
                        <th>结束时间</th>
                        <th>状态</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody class="msg"></tbody>
                </table>
                <div id="test1" style="text-align:center"></div>
            </div>
        </div>
    </div>
</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/common.js"></script>
<script>
layui.use(['layer', 'laypage'], function () {
    var layer = layui.layer;
    var laypage = layui.laypage;

    /* 当前分页状态；renderedCount 记录分页组件已渲染的总数，用于防循环 */
    var currPage = 1, currLimit = 10, totalCount = 0, renderedCount = -1;

    function syncPager() {
        if (renderedCount === totalCount) { return; }   // 总数无变化，不重复渲染
        renderedCount = totalCount;
        laypage.render({
            elem: 'test1',
            count: totalCount,
            curr: currPage,
            limit: currLimit,
            layout: ['count', 'prev', 'page', 'next', 'limit', 'skip'],
            limits: [10, 20, 50, 100],
            jump: function (obj) {
                var changed = (obj.curr !== currPage || obj.limit !== currLimit);
                currPage = obj.curr;
                currLimit = obj.limit;
                /* 仅在用户翻页/换条数时请求；首次渲染的 jump 不重复请求（数据已加载） */
                if (changed) { loadData(obj.curr, obj.limit); }
            }
        });
    }

    function loadData(page, limit) {
        var keyv = $('#key_v').val() || '';
        http.post('../ajax.php', {
            contents: 'mail', act: 'page',
            first: limit * (page - 1), limit: limit, key: keyv
        }).then(function (res) {
            if (res.code === 1) {
                totalCount = res.count;
                var html = '';
                res.data.forEach(function (d) {
                    var banned = (d.status !== undefined && parseInt(d.status) === 0);
                    var act = d.activated === undefined || parseInt(d.activated) === 1;
                    var stateTags = (banned
                            ? '<span class="label label-danger">已封禁</span>'
                            : '<span class="label label-primary">正常</span>')
                        + '&nbsp;' + (act
                            ? '<span class="label label-success">已激活</span>'
                            : '<span class="label label-default">未激活</span>');
                    var banBtn = banned
                        ? '<a href="javascript:;" onclick="ban_one(' + d.id + ',1)" class="btn btn-success btn-xs"><i class="fa fa-unlock"></i> 解封</a>'
                        : '<a href="javascript:;" onclick="ban_one(' + d.id + ',0)" class="btn btn-danger btn-xs"><i class="fa fa-ban"></i> 封禁</a>';
                    html += '<tr' + (banned ? ' style="background:#fdf0f0"' : '') + '>'
                        + '<td><input type="checkbox" name="checkname[]" value="' + d.id + '">&nbsp;&nbsp;' + d.id + '</td>'
                        + '<td>' + esc(d.uid) + '</td>'
                        + '<td>' + esc(d.mail) + '&nbsp;&nbsp;&nbsp;&nbsp;<span class="btn btn-primary btn-xs" onclick="recharge(' + d.id + ')">更新日期</span></td>'
                        + '<td>' + esc(d.yk_pwd) + '</td>'
                        + '<td>' + esc(d.pwd) + '</td>'
                        + '<td>' + is_time(d.add_time) + '</td>'
                        + '<td>' + is_time(d.end_time) + '</td>'
                        + '<td>' + stateTags + '</td>'
                        + '<td>'
                        + '<a href="javascript:;" onclick="del_data(' + d.id + ')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> 删除</a> '
                        + banBtn
                        + '</td>'
                        + '</tr>';
                });
                $('.msg').html(html || '<tr><td colspan="9" style="text-align:center;color:#999">暂无数据</td></tr>');
                syncPager();   // 用真实总数刷新分页组件
            } else {
                layer.msg(res.msg || '加载失败', {icon: 2});
            }
        }).catch(function () { layer.msg('请求异常', {icon: 2}); });
    }

    /* 首次加载：先取数据，再渲染分页 */
    loadData(1, 10);

    /* 搜索：回到第 1 页；总数变化后 loadData 内部会自动刷新分页 */
    $('#search_id').on('click', function () { currPage = 1; loadData(1, currLimit); });
    $('#key_v').on('keydown', function (ev) {
        if (ev.keyCode === 13) { ev.preventDefault(); currPage = 1; loadData(1, currLimit); }
    });

    /* -------- 暴露给 onclick -------- */
    window.del_data = function (id) {
        layer.confirm('确定删除这条数据吗？', function (index) {
            http.post('../ajax.php', {contents: 'mail', act: 'del', ids: id}).then(function (res) {
                if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
                else { layer.msg(res.msg || '删除失败', {icon: 0}); }
            });
            layer.close(index);
        });
    };
    window.del_order = function () {
        var ids = checkedIds();
        if (!ids.length) { layer.msg('请选择要删除的数据！'); return; }
        layer.confirm('确认删除选中吗?', {icon: 3, title: '提示'}, function (index) {
            http.post('../ajax.php', {contents: 'mail', act: 'del', ids: ids.join(',')}).then(function (res) {
                if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
                else { layer.msg(res.msg || '删除失败', {icon: 0}); }
            });
            layer.close(index);
        });
    };
    window.del_expired = function () {
        layer.confirm('确定一键删除所有已到期数据吗?', {icon: 3, title: '提示'}, function (index) {
            http.post('../ajax.php', {contents: 'mail', act: 'del_end'}).then(function (res) {
                if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
                else { layer.msg(res.msg || '删除失败', {icon: 0}); }
            });
            layer.close(index);
        });
    };
    window.execl_s = function () {
        var ids = checkedIds();
        if (!ids.length) { layer.msg('请选择数据', {icon: 2}); return; }
        layer.load(2);
        fetch('../ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({contents: 'mail', act: 'excel', uid: ids, csrf: CSRF})
        }).then(function (r) {
            if (!r.ok) throw new Error('fail');
            return r.blob();
        }).then(function (blob) {
            layer.closeAll('loading');
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url; a.download = '邮箱数据.xls';
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            layer.msg('导出成功', {icon: 1});
        }).catch(function () { layer.closeAll('loading'); layer.msg('导出失败', {icon: 2}); });
    };
    window.recharge = function (id) { up_date('acttime', id); };

    /* 封禁 / 解封单条 */
    window.ban_one = function (id, status) {
        var tip = status ? '确定解封这条卡密吗？' : '确定封禁这条卡密吗？封禁后前端将无法使用。';
        layer.confirm(tip, function (index) {
            http.post('../ajax.php', {contents: 'mail', act: 'ban', ids: id, status: status}).then(function (res) {
                if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
                else { layer.msg(res.msg || '操作失败', {icon: 0}); }
            });
            layer.close(index);
        });
    };

    /* 批量封禁 / 解封 */
    window.ban_batch = function (status) {
        var ids = checkedIds();
        if (!ids.length) { layer.msg('请先勾选卡密！'); return; }
        var tip = status ? '确定批量解封选中卡密吗？' : '确定批量封禁选中卡密吗？';
        layer.confirm(tip, function (index) {
            http.post('../ajax.php', {contents: 'mail', act: 'ban', ids: ids.join(','), status: status}).then(function (res) {
                if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
                else { layer.msg(res.msg || '操作失败', {icon: 0}); }
            });
            layer.close(index);
        });
    };

    window.up_time = function () {
        /* 打开增强版批量调整页：支持按 勾选/今天导入/指定日期导入 圈定账号 */
        var ids = checkedIds();
        var url = 'batch_date.php' + (ids.length ? '?ids=' + ids.join(',') : '');
        layer.open({
            type: 2,
            title: '批量调整结束日期',
            area: ['430px', '470px'],
            content: url
        });
    };
    window.up_date = function (act, uid) {
        var body = '<div style="padding:15px 20px 0">'
            + '<div class="form-group"><select class="form-control" id="actdo">'
            + '<option value="0">追加(天)</option><option value="1">扣除(天)</option></select></div>'
            + '<input type="text" id="rmb" placeholder="请输入天数" class="form-control">'
            + '</div>';
        layer.open({
            type: 1, title: '调整时间', area: ['320px', 'auto'], content: body,
            btn: ['确定', '取消'], yes: function (index) {
                var actdo = $('#actdo').val();
                var rmb = $('#rmb').val();
                if (!rmb || !/^\d+$/.test(rmb)) { layer.msg('请输入正确的天数', {icon: 5}); return; }
                http.post('../ajax.php', {contents: 'mail', act: act, uid: uid, actdo: actdo, rmb: rmb}).then(function (res) {
                    if (res.code === 1) { layer.msg(res.msg, {icon: 1}, function () { location.reload(); }); }
                    else { layer.msg(res.msg, {icon: 5}); }
                });
                layer.close(index);
            }
        });
    };

    function checkedIds() {
        var ids = [];
        $('input[name="checkname[]"]:checked').each(function () { ids.push(this.value); });
        return ids;
    }
    window.checkAll = function () {
        $('input[name="checkname[]"]').prop('checked', $('#all').is(':checked'));
    };
});
</script>
</body>
</html>
