<?php
/**
 * IMAP 登录探针：测试 imap.aliyun.com:993 是否接受该密码（标准 LOGIN）
 * 上传 admin/net_test.php，访问，可带 ?mail=xxx；诊断完删除
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
if (function_exists('require_login')) { require_login(); }
@set_time_limit(120);

$mail = trim((string)($_GET['mail'] ?? 'lanyu19950216@aliyun.com'));
$acc = one('SELECT * FROM mail_accounts WHERE mail=?', [$mail]);
$pass = $acc ? (string)$acc['pwd'] : '';

function imap_try(string $host, int $port, bool $ssl, string $mail, string $pass): array
{
    $log = [];
    $t = ($ssl ? 'ssl://' : '') . $host;
    $fp = @stream_socket_client("{$t}:{$port}", $eno, $estr, 8);
    if (!$fp) { return ["连接失败 {$estr}"]; }
    stream_set_timeout($fp, 12);
    $log[] = 'S: ' . trim((string)fgets($fp));

    /* 标准 LOGIN（密码加引号，转义反斜杠和引号） */
    $qmail = str_replace(['\\','"'], ['\\\\','\"'], $mail);
    $qpass = str_replace(['\\','"'], ['\\\\','\"'], $pass);
    fwrite($fp, "a1 LOGIN \"{$qmail}\" \"{$qpass}\"\r\n");
    $log[] = 'C: a1 LOGIN ...';
    /* 读完整应答（可能多行，直到以 a1 开头） */
    $resp = '';
    while (!feof($fp)) {
        $l = fgets($fp);
        if ($l === false) { break; }
        $resp .= $l;
        if (preg_match('/^a1\s+/', $l)) { break; }
    }
    $log[] = 'S: ' . trim($resp);

    /* 若登录成功，试 SELECT INBOX 看邮件数 */
    if (stripos($resp, 'a1 OK') !== false) {
        fwrite($fp, "a2 SELECT INBOX\r\n");
        $r2 = '';
        while (!feof($fp)) {
            $l = fgets($fp);
            if ($l === false) { break; }
            $r2 .= $l;
            if (preg_match('/^a2\s+/', $l)) { break; }
        }
        if (preg_match('/\*\s+(\d+)\s+EXISTS/i', $r2, $m)) {
            $log[] = "收件箱邮件数：{$m[1]}";
        }
    }
    fclose($fp);
    return $log;
}

$cases = [
    'imap.aliyun.com:993 SSL' => ['imap.aliyun.com', 993, true, $mail, $pass],
    'imap.aliyun.com:143 非加密' => ['imap.aliyun.com', 143, false, $mail, $pass],
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><title>IMAP登录探针</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body style="padding:25px">
<h3>IMAP 登录探针</h3>
<p>邮箱：<?= htmlspecialchars($mail) ?>　密码：<?= htmlspecialchars($pass) ?></p>
<?php foreach ($cases as $name => $c): ?>
<h5><?= htmlspecialchars($name) ?></h5>
<table class="table table-bordered" style="max-width:860px">
<?php foreach (imap_try(...$c) as $line):
    $bad = preg_match('/\bNO\b|BAD|失败/i', $line);
    $good = preg_match('/\bOK\b|EXISTS/i', $line);
    $col = $bad ? '#c0392b' : ($good ? '#2b8a3e' : '#444');
?>
<tr><td style="color:<?= $col ?>;font-family:monospace;white-space:pre-wrap"><?= htmlspecialchars($line) ?></td></tr>
<?php endforeach; ?>
</table>
<?php endforeach; ?>
<div style="max-width:860px;font-size:13px;color:#555">
· a1 OK 且能看到邮件数 → IMAP 可用，我改走 IMAP 取信。<br>
· a1 NO / 需安全密码 → 该邮箱未设“三方客户端安全密码”，只能回 POP 加密或中转。<br>
诊断完删除 <b>admin/net_test.php</b>。
</div>
</body>
</html>
