<?php
/**
 * 批量调整结束日期（按 勾选 / 今天导入 / 指定日期导入 圈定账号）
 * 自包含页面：自己的 CSRF + 自己的 PDO 连接，不依赖 ajax.php
 * 由账号列表页通过 layer iframe 打开
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
if (function_exists('require_login')) { require_login(); }

/* 本页独立 CSRF */
if (empty($_SESSION['batch_date_csrf'])) {
    $_SESSION['batch_date_csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['batch_date_csrf'];

$preIds = '';
if (isset($_GET['ids']) && is_string($_GET['ids'])) {
    $preIds = preg_replace('/[^\d,]/', '', $_GET['ids']);
}

/* ---------------- 处理提交 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $raw = file_get_contents('php://input');
    $in = json_decode($raw, true);
    if (!is_array($in)) { $in = $_POST; }

    if (($in['csrf'] ?? '') !== $csrf) {
        echo json_encode(['code' => 0, 'msg' => '安全校验失败，请关闭窗口重试']);
        exit;
    }

    $scope = in_array($in['scope'] ?? '', ['checked', 'today', 'date'], true) ? $in['scope'] : 'today';
    $mode  = in_array($in['mode'] ?? '', ['add', 'sub', 'set'], true) ? $in['mode'] : 'add';

    try {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);

        /* 构造 WHERE 与参数 */
        $where = '';
        $params = [];
        if ($scope === 'checked') {
            $ids = [];
            foreach (explode(',', (string)($in['ids'] ?? '')) as $x) {
                if ((int)$x > 0) { $ids[] = (int)$x; }
            }
            if (!$ids) { echo json_encode(['code' => 0, 'msg' => '请先勾选账号']); exit; }
            $place = implode(',', array_fill(0, count($ids), '?'));
            $where = "id IN ($place)";
            $params = $ids;
        } elseif ($scope === 'today') {
            $where = "DATE(add_time) = CURDATE()";
        } else {
            $d = (string)($in['import_date'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) {
                echo json_encode(['code' => 0, 'msg' => '请选择正确的导入日期']); exit;
            }
            $where = "DATE(add_time) = ?";
            $params = [$d];
        }

        /* 先统计会影响多少条 */
        $st = $pdo->prepare("SELECT COUNT(*) FROM mail_accounts WHERE $where");
        $st->execute($params);
        $cnt = (int)$st->fetchColumn();
        if ($cnt === 0) {
            echo json_encode(['code' => 0, 'msg' => '该范围内没有账号']);
            exit;
        }

        if ($mode === 'add' || $mode === 'sub') {
            $days = (int)($in['days'] ?? 0);
            if ($days <= 0) { echo json_encode(['code' => 0, 'msg' => '请输入正确的天数']); exit; }
            $op = $mode === 'add' ? 'DATE_ADD' : 'DATE_SUB';
            $sql = "UPDATE mail_accounts SET end_time = $op(COALESCE(end_time, NOW()), INTERVAL ? DAY) WHERE $where";
            array_unshift($params, $days);
        } else {
            $d = (string)($in['end_date'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) {
                echo json_encode(['code' => 0, 'msg' => '请选择正确的到期日期']); exit;
            }
            $sql = "UPDATE mail_accounts SET end_time = ? WHERE $where";
            array_unshift($params, $d . ' 23:59:59');
        }

        $up = $pdo->prepare($sql);
        $up->execute($params);
        echo json_encode(['code' => 1, 'msg' => "已更新 {$cnt} 条账号"]);
    } catch (Throwable $e) {
        echo json_encode(['code' => 0, 'msg' => '执行失败：' . $e->getMessage()]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>批量调整结束日期</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<style>
  body { padding: 18px 20px; font-family: "Microsoft YaHei", Arial, sans-serif; }
  .form-group { margin-bottom: 14px; }
  label { font-weight: 700; font-size: 13px; display: block; margin-bottom: 5px; color: #333; }
  .tip { font-size: 12px; color: #888; margin-top: 4px; }
  #msg { font-size: 13px; margin-top: 8px; min-height: 18px; }
</style>
</head>
<body>
<form id="f" onsubmit="return false;">
  <div class="form-group">
    <label>调整范围</label>
    <select class="form-control" id="scope">
      <option value="checked" <?= $preIds ? '' : 'disabled' ?>>勾选的账号<?= $preIds ? '' : '（未勾选，不可用）' ?></option>
      <option value="today" selected>今天导入的账号</option>
      <option value="date">指定日期导入的账号</option>
    </select>
  </div>

  <div class="form-group" id="dateBox" style="display:none">
    <label>导入日期</label>
    <input type="date" id="importDate" class="form-control" value="<?= date('Y-m-d') ?>">
  </div>

  <div class="form-group">
    <label>调整方式</label>
    <select class="form-control" id="mode">
      <option value="add">追加天数</option>
      <option value="sub">扣除天数</option>
      <option value="set">直接设置到期日</option>
    </select>
  </div>

  <div class="form-group" id="daysBox">
    <label>天数</label>
    <input type="number" id="days" class="form-control" min="1" placeholder="如 30">
  </div>

  <div class="form-group" id="setBox" style="display:none">
    <label>到期日期</label>
    <input type="date" id="endDate" class="form-control">
  </div>

  <input type="hidden" id="ids" value="<?= htmlspecialchars($preIds, ENT_QUOTES, 'UTF-8') ?>">
  <input type="hidden" id="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">

  <button class="btn btn-primary btn-block" id="okBtn">确定执行</button>
  <div id="msg"></div>
</form>

<script>
(function () {
    var scope = document.getElementById('scope');
    var mode = document.getElementById('mode');
    var dateBox = document.getElementById('dateBox');
    var daysBox = document.getElementById('daysBox');
    var setBox = document.getElementById('setBox');
    var msg = document.getElementById('msg');

    scope.onchange = function () {
        dateBox.style.display = scope.value === 'date' ? 'block' : 'none';
    };
    mode.onchange = function () {
        var isSet = mode.value === 'set';
        setBox.style.display = isSet ? 'block' : 'none';
        daysBox.style.display = isSet ? 'none' : 'block';
        dateBox.style.display = scope.value === 'date' ? 'block' : 'none';
    };

    document.getElementById('okBtn').onclick = function () {
        var payload = {
            csrf: document.getElementById('csrf').value,
            scope: scope.value,
            mode: mode.value,
            ids: document.getElementById('ids').value,
            days: document.getElementById('days').value,
            import_date: document.getElementById('importDate').value,
            end_date: document.getElementById('endDate').value
        };
        msg.style.color = '#888';
        msg.textContent = '执行中...';
        fetch('batch_date.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        }).then(function (r) { return r.json(); }).then(function (res) {
            if (res.code === 1) {
                msg.style.color = '#2b8a3e';
                msg.textContent = res.msg;
                setTimeout(function () {
                    try { parent.location.reload(); } catch (e) { location.reload(); }
                }, 800);
            } else {
                msg.style.color = '#c0392b';
                msg.textContent = res.msg;
            }
        }).catch(function () {
            msg.style.color = '#c0392b';
            msg.textContent = '请求异常，请重试';
        });
    };
})();
</script>
</body>
</html>
