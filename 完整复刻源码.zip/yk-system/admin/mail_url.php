<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';
require_login();
$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>查询地址 - 后台</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/style.css">
<meta name="csrf" content="<?= h($csrf) ?>">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
<div class="ibox"><div class="ibox-content">

  <div class="row" style="margin-bottom:16px">
    <form class="form-inline">
      <div class="form-group"><label>服务器：</label><input type="text" id="pop_host" class="form-control" placeholder="pop.aliyun.com"></div>
      <div class="form-group" style="margin-left:10px"><label>端口：</label><input type="number" id="pop_port" class="form-control" placeholder="110" style="width:100px"></div>
      <div class="form-group" style="margin-left:10px"><label>适用域名：</label><input type="text" id="pop_bz" class="form-control" placeholder="aliyun.com"></div>
      <button type="button" class="btn btn-primary" id="addBtn" style="margin-left:10px"><i class="fa fa-plus"></i> 添加</button>
    </form>
  </div>

  <table class="table table-bordered table-hover">
    <thead><tr><th>ID</th><th>收信服务器</th><th>端口</th><th>适用邮箱域名</th><th width="160">操作</th></tr></thead>
    <tbody id="list"></tbody>
  </table>

</div></div>
</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/common.js"></script>
<script>
layui.use(['layer'], function () {
    var layer = layui.layer;

    function load() {
        http.post('../ajax.php', {contents: 'url', act: 'page'}).then(function (res) {
            if (res.code !== 1) { layer.msg(res.msg, {icon: 2}); return; }
            var html = '';
            res.data.forEach(function (d) {
                html += '<tr><td>' + d.id + '</td>'
                    + '<td><input class="form-control input-sm" value="' + esc(d.pop_host) + '" data-k="pop_host" data-id="' + d.id + '"></td>'
                    + '<td><input class="form-control input-sm" value="' + esc(d.pop_port) + '" data-k="pop_port" data-id="' + d.id + '" style="width:90px"></td>'
                    + '<td><input class="form-control input-sm" value="' + esc(d.pop_bz) + '" data-k="pop_bz" data-id="' + d.id + '"></td>'
                    + '<td><button class="btn btn-primary btn-xs saveRow" data-id="' + d.id + '">保存</button> '
                    + '<button class="btn btn-danger btn-xs delRow" data-id="' + d.id + '">删除</button></td></tr>';
            });
            $('#list').html(html || '<tr><td colspan="5" class="text-center text-muted">暂无数据</td></tr>');
        });
    }

    $('#addBtn').on('click', function () {
        http.post('../ajax.php', {
            contents: 'url', act: 'add',
            pop_host: $('#pop_host').val(), pop_port: $('#pop_port').val(), pop_bz: $('#pop_bz').val()
        }).then(function (res) {
            if (res.code === 1) { layer.msg(res.msg, {icon: 1}); load(); }
            else { layer.msg(res.msg, {icon: 2}); }
        });
    });

    $('#list').on('click', '.saveRow', function () {
        var id = $(this).data('id'), p = {contents: 'url', act: 'update', id: id};
        $('input[data-id="' + id + '"]').each(function () { p[$(this).data('k')] = $(this).val(); });
        http.post('../ajax.php', p).then(function (res) { layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2}); });
    });

    $('#list').on('click', '.delRow', function () {
        var id = $(this).data('id');
        layer.confirm('确定删除？', function () {
            http.post('../ajax.php', {contents: 'url', act: 'del', id: id}).then(function (res) {
                layer.msg(res.msg, {icon: 1}); load();
            });
        });
    });

    load();
});
</script>
</body>
</html>
