<?php
/**
 * 后台主框架（修复版）
 * 修复点：菜单与默认 iframe 地址原来用权限表中的 "admin/mail.php"，
 *        在 /admin/index.php 内被相对解析成 /admin/admin/mail.php → 404。
 *        现统一按「当前 admin 目录的真实 web 路径 + 文件名」生成，
 *        兼容域名根部署与子目录部署。
 * 用法：上传覆盖 admin/index.php
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';

if (function_exists('require_login')) {
    $r = require_login();
} else {
    $r = null;
}

/* ---- 兼容不同函数名，拿到当前登录管理员 ---- */
$me = null;
if (function_exists('current_admin')) {
    $me = current_admin();
}
if (!is_array($me) && is_array($r)) {
    $me = $r;
}
if (!is_array($me)) {
    foreach (['admin_id', 'aid', 'id', 'uid'] as $k) {
        if (!empty($_SESSION[$k])) {
            $row = one('SELECT * FROM admin WHERE id = ?', [(int)$_SESSION[$k]]);
            if ($row) { $me = $row; break; }
        }
    }
}
if (!$me) {
    // 兜底：未登录直接跳登录页
    header('Location: login.php');
    exit;
}

/* ---- 当前 admin 目录的 web 路径，如 /admin 或 /yk/admin ---- */
$adminBase = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');

/* ---- 角色权限 ---- */
$role = one('SELECT * FROM roles WHERE id = ?', [(int)($me['role_id'] ?? 0)]);
$allPerms = $role && trim((string)$role['rules']) === '*';
$allow = [];
if (!$allPerms && $role) {
    foreach (explode(',', (string)$role['rules']) as $x) {
        if ((int)$x > 0) { $allow[(int)$x] = true; }
    }
}
$can = function ($id) use ($allPerms, $allow) {
    return $allPerms || isset($allow[(int)$id]);
};

$perms = q('SELECT * FROM permissions ORDER BY sort, id');

$tops = [];
foreach ($perms as $p) {
    if ((int)$p['pid'] === 0 && $can((int)$p['id'])) { $tops[] = $p; }
}
$kids = function ($pid) use ($perms, $can) {
    $out = [];
    foreach ($perms as $p) {
        if ((int)$p['pid'] === (int)$pid && $can((int)$p['id'])) { $out[] = $p; }
    }
    return $out;
};

/* 默认内容页：第一个有权限且带 url 的节点 */
$default = '';
foreach ($perms as $p) {
    if ($can((int)$p['id']) && trim((string)($p['url'] ?? '')) !== '') {
        $default = basename($p['url']);
        break;
    }
}
if ($default === '') { $default = 'uppwd.php'; }

$siteName = function_exists('cfg') ? (cfg('web_title') ?: '验证查询系统') : '验证查询系统';
$h = function ($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
};
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $h($siteName) ?> · 后台</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { height: 100%; font-family: "Microsoft YaHei", Arial, sans-serif; }
  body { display: flex; flex-direction: column; background: #f4f6f8; }
  .topbar { height: 50px; background: #222; color: #fff; display: flex; align-items: center;
            justify-content: space-between; padding: 0 18px; flex: 0 0 50px; }
  .topbar .brand { font-size: 17px; font-weight: 700; }
  .topbar .links a { color: #ddd; text-decoration: none; margin-left: 22px; font-size: 14px; }
  .topbar .links a:hover { color: #fff; }
  .wrap { flex: 1; display: flex; min-height: 0; }
  .sidebar { width: 190px; background: #2f3a45; overflow-y: auto; flex: 0 0 190px; }
  .sidebar .group { padding: 12px 0 4px 16px; color: #9fb0c0; font-size: 13px; }
  .sidebar a { display: block; padding: 9px 0 9px 26px; color: #d6dee6; text-decoration: none;
               font-size: 14px; border-left: 3px solid transparent; }
  .sidebar a:hover, .sidebar a.active { background: #26303a; color: #fff; border-left-color: #4a90d9; }
  .main { flex: 1; border: 0; background: #fff; width: 100%; }
</style>
</head>
<body>
  <div class="topbar">
    <div class="brand"><?= $h($siteName) ?> · 后台</div>
    <div class="links">
      <span style="color:#bbb;">&#128100; <?= $h($me['username'] ?? '') ?></span>
      <a href="<?= $h($adminBase) ?>/uppwd.php" target="mainFrame">&#128269; 修改密码</a>
      <a href="<?= $h($adminBase) ?>/logout.php" target="_top">&#128682; 退出</a>
    </div>
  </div>
  <div class="wrap">
    <div class="sidebar" id="sidebar">
      <?php foreach ($tops as $top):
        $children = $kids((int)$top['id']);
        if (!$children) { continue; }
      ?>
        <div class="group"><?= $h($top['name']) ?></div>
        <?php foreach ($children as $c):
          $href = $adminBase . '/' . basename((string)$c['url']);
        ?>
          <a href="<?= $h($href) ?>" target="mainFrame"><?= $h($c['name']) ?></a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </div>
    <iframe class="main" name="mainFrame" src="<?= $h($adminBase . '/' . $default) ?>"></iframe>
  </div>
  <script>
  (function () {
    try {
      var links = document.getElementById('sidebar').getElementsByTagName('a');
      for (var i = 0; i < links.length; i++) {
        links[i].onclick = function () {
          for (var j = 0; j < links.length; j++) { links[j].classList.remove('active'); }
          this.classList.add('active');
        };
      }
    } catch (e) { /* 忽略，不影响使用 */ }
  })();
  </script>
</body>
</html>
