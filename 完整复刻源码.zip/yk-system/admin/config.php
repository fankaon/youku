<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';
require_login();
$csrf = csrf_token();
$g = function ($k, $d = '') { return h(cfg($k, $d)); };
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>系统配置 - 后台</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/style.css">
<meta name="csrf" content="<?= h($csrf) ?>">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
<div class="ibox"><div class="ibox-content" style="max-width:720px">

<h4>基础设置</h4>
<div class="form-group"><label>系统名称</label><input type="text" id="web_title" class="form-control" value="<?= $g('web_title','验证查询系统') ?>"></div>
<div class="form-group"><label>前端公告(可空)</label><textarea id="web_notice" class="form-control" rows="3"><?= $g('web_notice') ?></textarea></div>
<div class="form-group"><label>登录视频教程地址(可空)</label><input type="text" id="tutorial_video" class="form-control" value="<?= $g('tutorial_video') ?>"></div>
<div class="form-group"><label>图片教程地址(可空)</label><input type="text" id="tutorial_image" class="form-control" value="<?= $g('tutorial_image') ?>"></div>

<hr>
<h4>代理查码（服务器直连邮箱失败时使用）</h4>
<div class="form-group">
  <label>是否启用代理</label>
  <select id="is_proxy" class="form-control" style="max-width:160px">
    <option value="0" <?= cfg('is_proxy') === '1' ? '' : 'selected' ?>>关闭</option>
    <option value="1" <?= cfg('is_proxy') === '1' ? 'selected' : '' ?>>开启</option>
  </select>
</div>
<div class="form-group">
  <label>代理类型</label>
  <select id="proxy_type" class="form-control" style="max-width:160px">
    <option value="0" <?= cfg('proxy_type') === '1' ? '' : 'selected' ?>>SOCKS5</option>
    <option value="1" <?= cfg('proxy_type') === '1' ? 'selected' : '' ?>>HTTP</option>
  </select>
</div>
<div class="form-group"><label>SOCKS5 地址（格式 socks5://IP:端口）</label><input type="text" id="socks_host" class="form-control" value="<?= $g('socks_host') ?>"></div>
<div class="row">
  <div class="col-sm-6"><div class="form-group"><label>SOCKS5 用户名(可空)</label><input type="text" id="socks_user" class="form-control" value="<?= $g('socks_user') ?>"></div></div>
  <div class="col-sm-6"><div class="form-group"><label>SOCKS5 密码(可空)</label><input type="text" id="socks_pass" class="form-control" value="<?= $g('socks_pass') ?>"></div></div>
</div>
<div class="form-group"><label>HTTP 代理（格式 http://IP:端口）</label><input type="text" id="http_proxy" class="form-control" value="<?= $g('http_proxy') ?>"></div>

<button class="btn btn-primary" id="saveBtn"><i class="fa fa-save"></i> 保存配置</button>

</div></div>
</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/common.js"></script>
<script>
layui.use(['layer'], function () {
    var layer = layui.layer;
    $('#saveBtn').on('click', function () {
        var keys = ['web_title','web_notice','tutorial_video','tutorial_image','is_proxy','proxy_type','socks_host','socks_user','socks_pass','http_proxy'];
        var data = {contents: 'config', act: 'save'};
        keys.forEach(function (k) { data[k] = $('#' + k).val(); });
        http.post('../ajax.php', data).then(function (res) {
            layer.msg(res.msg, {icon: res.code === 1 ? 1 : 2});
        });
    });
});
</script>
</body>
</html>
