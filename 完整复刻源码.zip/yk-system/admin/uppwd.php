<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/functions.php';
$me = require_login();
$csrf = csrf_token();
$msg = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $old = (string)($_POST['old_pwd'] ?? '');
    $new = (string)($_POST['new_pwd'] ?? '');
    $again = (string)($_POST['again_pwd'] ?? '');
    if (!verify_password($old, (string)$me['password'])) {
        $msg = ['原密码错误', 0];
    } elseif (strlen($new) < 6) {
        $msg = ['新密码至少 6 位', 0];
    } elseif ($new !== $again) {
        $msg = ['两次输入的新密码不一致', 0];
    } else {
        db()->prepare('UPDATE admin SET password=? WHERE id=?')
            ->execute([hash_password($new), (int)$me['id']]);
        $msg = ['密码修改成功', 1];
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>修改密码 - 后台</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
<div class="ibox"><div class="ibox-content" style="max-width:440px">
<h4>修改密码</h4>
<?php if ($msg): ?>
  <div class="alert alert-<?= $msg[1] ? 'success' : 'danger' ?>" style="margin-top:14px"><?= h($msg[0]) ?></div>
<?php endif; ?>
<form method="post" style="margin-top:14px">
  <div class="form-group"><label>原密码</label><input type="password" name="old_pwd" class="form-control" required></div>
  <div class="form-group"><label>新密码</label><input type="password" name="new_pwd" class="form-control" required></div>
  <div class="form-group"><label>确认新密码</label><input type="password" name="again_pwd" class="form-control" required></div>
  <button type="submit" class="btn btn-primary">确认修改</button>
</form>
</div></div>
</div>
</body>
</html>
