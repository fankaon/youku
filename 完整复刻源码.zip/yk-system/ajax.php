<?php
/**
 * 统一接口：后台所有数据操作入口
 * 入参：JSON（contents / act / ...）
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/functions.php';
require_once __DIR__ . '/lib/excel.php';
require_once __DIR__ . '/lib/mail_query.php';

$me = require_login();
$in = request_in();

/* CSRF 校验 */
if (!csrf_check($in['csrf'] ?? null)) {
    json_out(['code' => 0, 'msg' => '安全校验失败，请刷新页面重试']);
}

$contents = (string)($in['contents'] ?? '');
$act = (string)($in['act'] ?? '');

try {
    switch ($contents) {

        /* =========================================================
         *  账号管理
         * ========================================================= */
        case 'mail':
            switch ($act) {

                case 'page': {
                    $first = max(0, (int)($in['first'] ?? 0));
                    $limit = min(1000, max(1, (int)($in['limit'] ?? 10)));
                    $key = trim((string)($in['key'] ?? ''));
                    $where = 'WHERE 1=1';
                    $p = [];
                    if ($key !== '') {
                        $where .= " AND (mail LIKE ? ESCAPE '!' OR uid LIKE ? ESCAPE '!')";
                        $lk = '%' . like_escape($key) . '%';
                        $p = [$lk, $lk];
                    }
                    $count = (int)qv("SELECT COUNT(*) FROM mail_accounts $where", $p);
                    $data = q("SELECT * FROM mail_accounts $where ORDER BY id DESC LIMIT $first,$limit", $p);
                    json_out(['code' => 1, 'count' => $count, 'data' => $data]);
                }

                case 'del': {
                    $ids = normalize_ids($in['ids'] ?? '');
                    if (!$ids) { json_out(['code' => 0, 'msg' => '请选择要删除的数据']); }
                    $ph = implode(',', array_fill(0, count($ids), '?'));
                    db()->prepare("DELETE FROM mail_accounts WHERE id IN ($ph)")->execute($ids);
                    json_out(['code' => 1, 'msg' => '删除成功，共 ' . count($ids) . ' 条']);
                }

                case 'del_end': {
                    $st = db()->prepare("DELETE FROM mail_accounts WHERE end_time IS NOT NULL AND end_time < NOW()");
                    $st->execute();
                    json_out(['code' => 1, 'msg' => '已删除到期账号 ' . $st->rowCount() . ' 条']);
                }

                case 'ban': {
                    $ids = normalize_ids($in['ids'] ?? '');
                    if (!$ids) { json_out(['code' => 0, 'msg' => '请选择卡密']); }
                    $status = (int)($in['status'] ?? 0) === 1 ? 1 : 0;
                    $ph = implode(',', array_fill(0, count($ids), '?'));
                    db()->prepare("UPDATE mail_accounts SET status = ? WHERE id IN ($ph)")
                        ->execute(array_merge([$status], $ids));
                    json_out(['code' => 1, 'msg' => ($status ? '解封' : '封禁') . '成功，共 ' . count($ids) . ' 条']);
                }

                case 'excel': {
                    $ids = normalize_ids($in['uid'] ?? []);
                    if (!$ids) { json_out(['code' => 0, 'msg' => '请选择要导出的数据']); }
                    $ph = implode(',', array_fill(0, count($ids), '?'));
                    $rows = q("SELECT * FROM mail_accounts WHERE id IN ($ph) ORDER BY id DESC", $ids);
                    export_accounts_excel($rows);
                    exit;
                }

                case 'acttime': {
                    $id = (int)($in['uid'] ?? 0);
                    $days = (int)($in['rmb'] ?? 0);
                    if ($id <= 0 || $days <= 0) { json_out(['code' => 0, 'msg' => '参数错误']); }
                    $op = ((int)($in['actdo'] ?? 0) === 1) ? 'DATE_SUB' : 'DATE_ADD';
                    db()->prepare("UPDATE mail_accounts SET end_time = $op(COALESCE(end_time,NOW()), INTERVAL ? DAY) WHERE id = ?")
                        ->execute([$days, $id]);
                    json_out(['code' => 1, 'msg' => '日期调整成功']);
                }

                case 'add': {
                    $mail = trim((string)($in['mail'] ?? ''));
                    if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) { json_out(['code' => 0, 'msg' => '邮箱格式不正确']); }
                    if (one('SELECT id FROM mail_accounts WHERE mail = ?', [$mail])) {
                        json_out(['code' => 0, 'msg' => '该账号已存在']);
                    }
                    $uid = make_token();
                    $end = trim((string)($in['end_time'] ?? ''));
                    $end = preg_match('/^\d{4}-\d{2}-\d{2}$/', $end) ? $end . ' 23:59:59' : null;
                    qi('INSERT INTO mail_accounts (uid, mail, yk_pwd, pwd, add_time, end_time) VALUES (?,?,?,?,?,?)',
                        [$uid, $mail, (string)($in['yk_pwd'] ?? ''), (string)($in['pwd'] ?? ''), date('Y-m-d H:i:s'), $end]);
                    json_out(['code' => 1, 'msg' => '添加成功']);
                }

                case 'import': {
                    $text = (string)($in['text'] ?? '');
                    $n = batch_import($text);
                    json_out(['code' => 1, 'msg' => "导入完成，成功 {$n} 条"]);
                }

                default:
                    json_out(['code' => 0, 'msg' => '未知操作']);
            }
            break;

        /* =========================================================
         *  收信服务器（查询地址）
         * ========================================================= */
        case 'url':
            switch ($act) {
                case 'page':
                    json_out(['code' => 1, 'data' => q('SELECT * FROM mail_url ORDER BY id DESC')]);

                case 'add': {
                    $host = trim((string)($in['pop_host'] ?? ''));
                    $port = (int)($in['pop_port'] ?? 0);
                    $bz = trim((string)($in['pop_bz'] ?? ''));
                    if ($host === '' || $port <= 0 || $bz === '') { json_out(['code' => 0, 'msg' => '请填写完整']); }
                    qi('INSERT INTO mail_url (pop_host, pop_port, pop_bz, add_time) VALUES (?,?,?,?)',
                        [$host, $port, $bz, date('Y-m-d H:i:s')]);
                    json_out(['code' => 1, 'msg' => '添加成功']);
                }

                case 'update': {
                    $id = (int)($in['id'] ?? 0);
                    if ($id <= 0) { json_out(['code' => 0, 'msg' => '参数错误']); }
                    db()->prepare('UPDATE mail_url SET pop_host=?, pop_port=?, pop_bz=? WHERE id=?')
                        ->execute([trim((string)$in['pop_host']), (int)$in['pop_port'], trim((string)$in['pop_bz']), $id]);
                    json_out(['code' => 1, 'msg' => '修改成功']);
                }

                case 'del': {
                    $id = (int)($in['id'] ?? 0);
                    db()->prepare('DELETE FROM mail_url WHERE id=?')->execute([id]);
                    json_out(['code' => 1, 'msg' => '删除成功']);
                }

                default:
                    json_out(['code' => 0, 'msg' => '未知操作']);
            }
            break;

        /* =========================================================
         *  角色管理
         * ========================================================= */
        case 'rules':
            switch ($act) {
                case 'page':
                    json_out(['code' => 1, 'data' => q('SELECT * FROM roles ORDER BY id')]);

                case 'add': {
                    $name = trim((string)($in['name'] ?? ''));
                    if ($name === '') { json_out(['code' => 0, 'msg' => '请填写角色名称']); }
                    qi('INSERT INTO roles (name, rules, add_time) VALUES (?,?,?)',
                        [$name, normalize_rules($in['rules'] ?? '*'), date('Y-m-d H:i:s')]);
                    json_out(['code' => 1, 'msg' => '添加成功']);
                }

                case 'update': {
                    $id = (int)($in['id'] ?? 0);
                    db()->prepare('UPDATE roles SET name=?, rules=? WHERE id=?')
                        ->execute([trim((string)$in['name']), normalize_rules($in['rules'] ?? '*'), $id]);
                    json_out(['code' => 1, 'msg' => '修改成功']);
                }

                case 'del': {
                    $id = (int)($in['id'] ?? 0);
                    if ($id === 1) { json_out(['code' => 0, 'msg' => '超级管理员角色不可删除']); }
                    if (one('SELECT id FROM admin WHERE role_id=?', [$id])) { json_out(['code' => 0, 'msg' => '该角色下仍有管理员']); }
                    db()->prepare('DELETE FROM roles WHERE id=?')->execute([id]);
                    json_out(['code' => 1, 'msg' => '删除成功']);
                }

                default:
                    json_out(['code' => 0, 'msg' => '未知操作']);
            }
            break;

        /* =========================================================
         *  管理员管理
         * ========================================================= */
        case 'manage':
            switch ($act) {
                case 'page':
                    json_out(['code' => 1, 'data' => q('SELECT a.id,a.username,a.role_id,a.status,a.add_time,a.last_time,a.last_ip,r.name role_name FROM admin a LEFT JOIN roles r ON r.id=a.role_id ORDER BY a.id')]);

                case 'add': {
                    $u = trim((string)($in['username'] ?? ''));
                    $p = (string)($in['password'] ?? '');
                    if ($u === '' || strlen($p) < 6) { json_out(['code' => 0, 'msg' => '用户名不能为空，密码至少6位']); }
                    if (one('SELECT id FROM admin WHERE username=?', [$u])) { json_out(['code' => 0, 'msg' => '用户名已存在']); }
                    qi('INSERT INTO admin (username,password,role_id,status,add_time) VALUES (?,?,?,?,?)',
                        [$u, hash_password($p), (int)($in['role_id'] ?? 1), 1, date('Y-m-d H:i:s')]);
                    json_out(['code' => 1, 'msg' => '添加成功']);
                }

                case 'update': {
                    $id = (int)($in['id'] ?? 0);
                    db()->prepare('UPDATE admin SET role_id=?, status=? WHERE id=?')
                        ->execute([(int)($in['role_id'] ?? 1), (int)($in['status'] ?? 1), $id]);
                    if (!empty($in['password'])) {
                        if (strlen((string)$in['password']) < 6) { json_out(['code' => 0, 'msg' => '密码至少6位']); }
                        db()->prepare('UPDATE admin SET password=? WHERE id=?')
                            ->execute([hash_password((string)$in['password']), $id]);
                    }
                    json_out(['code' => 1, 'msg' => '修改成功']);
                }

                case 'del': {
                    $id = (int)($in['id'] ?? 0);
                    if ($id === (int)$me['id']) { json_out(['code' => 0, 'msg' => '不能删除当前登录账号']); }
                    if ($id === 1) { json_out(['code' => 0, 'msg' => '初始管理员不可删除']); }
                    db()->prepare('DELETE FROM admin WHERE id=?')->execute([id]);
                    json_out(['code' => 1, 'msg' => '删除成功']);
                }

                default:
                    json_out(['code' => 0, 'msg' => '未知操作']);
            }
            break;

        /* =========================================================
         *  系统配置
         * ========================================================= */
        case 'config':
            if ($act === 'save') {
                $allow = ['web_title', 'web_notice', 'is_proxy', 'proxy_type', 'socks_host', 'socks_user', 'socks_pass', 'http_proxy', 'tutorial_video', 'tutorial_image'];
                foreach ($allow as $k) {
                    if (array_key_exists($k, $in)) { set_cfg($k, trim((string)$in[$k])); }
                }
                json_out(['code' => 1, 'msg' => '配置已保存']);
            }
            json_out(['code' => 0, 'msg' => '未知操作']);

        default:
            json_out(['code' => 0, 'msg' => '未知模块']);
    }
} catch (Throwable $e) {
    json_out(['code' => 0, 'msg' => '服务器错误：' . $e->getMessage()]);
}

/* =========================================================
 *  辅助函数
 * ========================================================= */
function normalize_ids($v): array
{
    if (is_array($v)) {
        return array_values(array_unique(array_map('intval', $v)));
    }
    $v = (string)$v;
    $ids = [];
    foreach (preg_split('/[,\s]+/', $v, -1, PREG_SPLIT_NO_EMPTY) as $x) {
        if ((int)$x > 0) { $ids[] = (int)$x; }
    }
    return array_values(array_unique($ids));
}

function normalize_rules($v): string
{
    if (is_string($v)) {
        $t = trim($v);
        if ($t === '' || $t === '*') { return '*'; }
        $ids = [];
        foreach (explode(',', $t) as $x) { if ((int)$x > 0) { $ids[] = (int)$x; } }
        return $ids ? implode(',', array_unique($ids)) : '*';
    }
    if (is_array($v)) {
        $ids = array_filter(array_map('intval', $v));
        return $ids ? implode(',', array_unique($ids)) : '*';
    }
    return '*';
}

/* 批量导入：每行一条，支持 “邮箱,优酷密码,邮箱密码” 或 “邮箱----优酷密码----邮箱密码” */
function batch_import(string $text): int
{
    $existing = [];
    foreach (q('SELECT mail FROM mail_accounts') as $r) { $existing[(string)$r['mail']] = true; }

    $n = 0;
    foreach (preg_split('/\r?\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '') { continue; }
        $parts = preg_split('/(?:,|，|----|\s+----\s*|;|；|\t)/', $line);
        $parts = array_values(array_filter(array_map('trim', $parts), function ($x) { return $x !== ''; }));
        if (count($parts) < 1) { continue; }
        $mail = $parts[0];
        if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) { continue; }
        if (isset($existing[$mail])) { continue; }
        $yk = $parts[1] ?? '';
        $pw = $parts[2] ?? '';
        $uid = make_token();
        qi('INSERT INTO mail_accounts (uid, mail, yk_pwd, pwd, add_time, end_time) VALUES (?,?,?,?,?,?)',
            [$uid, $mail, $yk, $pw, date('Y-m-d H:i:s'), null]);
        $existing[$mail] = true;
        $n++;
    }
    return $n;
}
