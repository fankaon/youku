<?php
/**
 * 客户端：凭 token 查看账号信息
 *  GET  /?token=xxxx        展示账号
 *  POST / urls=<邮箱>       查询验证码（返回 JSON）
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/functions.php';
require_once __DIR__ . '/lib/mail_query.php';

/* ---------- POST：查验证码 ---------- */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['urls'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(query_verify_code((string)$_POST['urls']), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- GET：展示页 ---------- */
$token = trim((string)($_GET['token'] ?? ''));
$acc = $token !== '' ? one('SELECT * FROM mail_accounts WHERE uid = ?', [$token]) : null;
$siteName = cfg('web_title', '验证查询系统');
$notice = cfg('web_notice', '');
$video = cfg('tutorial_video', '');
$image = cfg('tutorial_image', '');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($siteName) ?>-客户端</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/layui.css">
<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<script src="/js/clipboard.min.js"></script>
<style>
  body { background: #f0f2f5; }
  .card-box { max-width: 560px; margin: 40px auto; background: #fff; border-radius: 10px;
              box-shadow: 0 4px 20px rgba(0,0,0,.08); padding: 30px 34px; }
  .line { display: flex; align-items: center; border: 1px solid #eee; border-radius: 6px;
          height: 46px; margin-bottom: 18px; overflow: hidden; }
  .line .lab { width: 92px; flex: 0 0 92px; background: #fafafa; height: 100%; display: flex;
               align-items: center; justify-content: center; font-size: 13px; color: #666; }
  .line .val { flex: 1; padding: 0 12px; font-size: 14px; word-break: break-all; }
  .line .cp { margin-right: 10px; }
  #msg { min-height: 24px; font-size: 14px; margin: 6px 0 14px; }
  .tut a { margin-right: 18px; }
  @media (max-width: 500px) { .card-box { margin: 16px; padding: 20px; } }
</style>
</head>
<body>
<div class="card-box">
<?php if (!$acc): ?>
    <div class="text-center" style="padding:30px 0;color:#888">
        <h4>卡密无效或不存在</h4>
        <p style="margin-top:12px;font-size:13px">请检查链接中的 token 是否完整，或联系卖家。</p>
        <p style="margin-top:6px"><a href="/activate.php" style="font-size:13px">前往激活卡密</a></p>
    </div>
<?php elseif (isset($acc['status']) && (int)$acc['status'] === 0): ?>
    <div class="text-center" style="padding:30px 0;color:#c0392b">
        <h4>该卡密已被停用</h4>
        <p style="margin-top:12px;font-size:13px">如有疑问请联系卖家处理。</p>
    </div>
<?php elseif (isset($acc['activated']) && (int)$acc['activated'] === 0): ?>
    <div class="text-center" style="padding:24px 0">
        <h4 style="color:#e67e22">卡密未激活</h4>
        <p style="margin-top:12px;font-size:13px;color:#777">激活后才会开始计算有效期，请先点击下方按钮激活。</p>
        <a class="btn btn-primary" style="margin-top:10px;height:44px;line-height:30px;padding:0 30px"
           href="/activate.php?token=<?= h($acc['uid']) ?>">立即激活此卡密</a>
    </div>
<?php else:
    if (!empty($acc['end_time']) && strtotime((string)$acc['end_time']) < time()) {
        echo '<div class="text-center" style="padding:20px 0;color:#c0392b"><h4>该账号已到期</h4></div>';
    }
?>
    <h4 class="text-center" style="margin-bottom:24px"><?= h($siteName) ?></h4>

    <div class="line">
        <div class="lab">优酷账号</div>
        <div class="val"><?= h($acc['mail']) ?></div>
        <button class="btn btn-success btn-xs cp" data-clipboard-text="<?= h($acc['mail']) ?>">复制</button>
    </div>
    <div class="line">
        <div class="lab">优酷密码</div>
        <div class="val"><?= h($acc['yk_pwd']) ?></div>
        <button class="btn btn-success btn-xs cp" data-clipboard-text="<?= h($acc['yk_pwd']) ?>">复制</button>
    </div>
    <div class="line">
        <div class="lab">查询地址</div>
        <div class="val"><button class="btn btn-primary" id="queryBtn">点击查询验证码</button></div>
    </div>

    <div id="msg"></div>

    <?php if ($notice !== ''): ?>
        <div style="background:#fff8e6;border:1px solid #ffe1a8;color:#8a6d3b;font-size:13px;
                    border-radius:6px;padding:10px 12px;margin-bottom:16px"><?= nl2br(h($notice)) ?></div>
    <?php endif; ?>

    <div class="tut" style="font-size:13px">
        <?php if ($video !== ''): ?>
            <a href="<?= h($video) ?>" target="_blank">优酷登录视频 <span class="btn btn-success btn-xs">点击查看</span></a>
        <?php endif; ?>
        <?php if ($image !== ''): ?>
            <a href="javascript:;" id="imgTut">图片教程 <span class="btn btn-success btn-xs">点击查看</span></a>
        <?php endif; ?>
    </div>
<?php endif; ?>
</div>

<script>
layui.use(['layer'], function () {
    var layer = layui.layer;

    /* 复制 */
    var cb = new ClipboardJS('.cp');
    cb.on('success', function () { layer.msg('复制成功', {icon: 1}); });
    cb.on('error', function () { layer.msg('复制失败，请手动选择', {icon: 2}); });

    /* 图片教程 */
    $('#imgTut').on('click', function () {
        layer.open({ type: 1, title: false, closeBtn: 1, area: ['auto', '90%'],
            content: '<img src="<?= h($image) ?>" style="max-width:100%;display:block">' });
    });

    /* 查询验证码：异步 + loading，避免页面卡死 */
    var loading = false;
    $('#queryBtn').on('click', function () {
        if (loading) { return; }
        loading = true;
        var btn = $(this); btn.attr('disabled', true).text('查询中，请稍候…');
        $('#msg').css('color', '#888').text('正在登录邮箱读取验证码，大约需要 10-30 秒…');
        var loadIdx = layer.load(2);

        $.ajax({
            type: 'POST', url: '/',
            data: {urls: '<?= h($acc['mail'] ?? '') ?>'},
            dataType: 'json',
            timeout: 115000,
            success: function (res) {
                layer.close(loadIdx);
                if (res.code === 1) {
                    $('#msg').css('color', '#2b8a3e').html(res.msg);
                } else {
                    $('#msg').css('color', '#c0392b').text(res.msg || '查询失败');
                }
            },
            error: function () {
                layer.close(loadIdx);
                $('#msg').css('color', '#c0392b').text('请求超时，请重试或联系卖家');
            },
            complete: function () {
                loading = false;
                btn.attr('disabled', false).text('点击查询验证码');
            }
        });
    });
});
</script>
</body>
</html>
