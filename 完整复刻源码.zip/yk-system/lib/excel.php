<?php
/**
 * Excel 导出：以 Excel 可识别的 HTML 表格输出 .xls（无需第三方扩展）
 */
function export_accounts_excel(array $rows): void
{
    $head = ['ID', 'TOKEN', '账号(邮箱)', '优酷密码', '邮箱密码', '创建时间', '结束时间'];
    $html = '<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head>';
    $html .= '<table border="1"><thead><tr>';
    foreach ($head as $c) { $html .= '<th>' . htmlspecialchars($c, ENT_QUOTES) . '</th>'; }
    $html .= '</tr></thead><tbody>';
    foreach ($rows as $r) {
        $cells = [$r['id'], $r['uid'], $r['mail'], $r['yk_pwd'], $r['pwd'], $r['add_time'], $r['end_time']];
        $html .= '<tr>';
        foreach ($cells as $c) { $html .= '<td>' . htmlspecialchars((string)$c, ENT_QUOTES) . '</td>'; }
        $html .= '</tr>';
    }
    $html .= '</tbody></table></html>';

    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="accounts_' . date('YmdHis') . '.xls"');
    header('Cache-Control: max-age=0');
    echo $html;
}
