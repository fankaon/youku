<?php
/**
 * IMAP 客户端（纯 PHP，支持 SSL；标准 LOGIN）
 * 用于读取收件箱最近邮件
 */
class Imap
{
    public string $error = '';
    /** @var resource|null */
    private $fp = null;
    private int $n = 0;
    private int $timeout;

    public function __construct(string $host, int $port, bool $ssl = false, int $timeout = 8)
    {
        $this->timeout = $timeout;
        $target = ($ssl ? 'ssl://' : '') . $host;
        $fp = @stream_socket_client("{$target}:{$port}", $eno, $estr, $timeout);
        if (!$fp) { $this->error = "连接失败 {$host}:{$port}"; return; }
        stream_set_timeout($fp, $this->timeout);
        $greet = fgets($fp);
        if ($greet === false || strpos(ltrim($greet), '* OK') !== 0) {
            $this->error = 'IMAP 服务器无响应'; fclose($fp); return;
        }
        $this->fp = $fp;
    }

    public function ok(): bool { return $this->fp !== null; }

    public function login(string $user, string $pass): bool
    {
        if (!$this->fp) { return false; }
        $u = $this->quote($user);
        $p = $this->quote($pass);
        [$ok, $resp] = $this->command("LOGIN {$u} {$p}");
        if (!$ok) {
            $this->error = strpos($resp, 'NO') !== false ? '邮箱密码错误或未开启IMAP' : '登录被拒';
            return false;
        }
        return true;
    }

    /** 选择收件箱，返回邮件总数 */
    public function select_inbox(): int
    {
        if (!$this->fp) { return 0; }
        [$ok, $resp] = $this->command('SELECT INBOX');
        if ($ok && preg_match('/\*\s+(\d+)\s+EXISTS/i', $resp, $m)) {
            return (int)$m[1];
        }
        return 0;
    }

    /** 取第 i 封邮件原文（i 从 1 开始） */
    public function message(int $i): string
    {
        if (!$this->fp) { return ''; }
        $tag = $this->next_tag();
        fwrite($this->fp, "{$tag} FETCH {$i} (BODY[])\r\n");

        while (!feof($this->fp)) {
            $l = fgets($this->fp);
            if ($l === false) { break; }
            /* 命中字面量 {长度} */
            if (preg_match('/\{(\d+)\}\r?\n$/', $l, $m)) {
                $len = (int)$m[1];
                $msg = $this->read_exact($len);
                $this->drain_to_tag($tag);
                return $msg;
            }
            if (preg_match('/^' . $tag . '\s+(NO|BAD)/', $l)) { return ''; }
        }
        return '';
    }

    public function close(): void
    {
        if ($this->fp) {
            @fwrite($this->fp, $this->next_tag() . " LOGOUT\r\n");
            @fclose($this->fp);
            $this->fp = null;
        }
    }

    /* ---------------- 内部 ---------------- */
    private function next_tag(): string
    {
        $this->n++;
        return 'A' . $this->n;
    }

    private function command(string $cmd): array
    {
        $tag = $this->next_tag();
        fwrite($this->fp, "{$tag} {$cmd}\r\n");
        $resp = '';
        while (!feof($this->fp)) {
            $l = fgets($this->fp);
            if ($l === false) { break; }
            /* 应答中可能含字面量（一般登录没有，稳妥处理） */
            if (preg_match('/\{(\d+)\}\r?\n$/', $l, $m)) {
                $resp .= $l . $this->read_exact((int)$m[1]);
                continue;
            }
            $resp .= $l;
            if (preg_match('/^' . $tag . '\s+(OK|NO|BAD)/', $l)) { break; }
        }
        return [(bool)preg_match('/^' . $tag . '\s+OK/', $resp), $resp];
    }

    private function drain_to_tag(string $tag): void
    {
        while (!feof($this->fp)) {
            $l = fgets($this->fp);
            if ($l === false) { break; }
            if (preg_match('/^' . $tag . '\s+(OK|NO|BAD)/', $l)) { return; }
        }
    }

    private function read_exact(int $len): string
    {
        $buf = '';
        while (strlen($buf) < $len && !feof($this->fp)) {
            $left = $len - strlen($buf);
            $chunk = fread($this->fp, $left);
            if ($chunk === false || $chunk === '') { break; }
            $buf .= $chunk;
        }
        return $buf;
    }

    private function quote(string $s): string
    {
        return '"' . str_replace(['\\', '"'], ['\\\\', '\"'], $s) . '"';
    }
}
