<?php
/**
 * 通用函数库
 */
require_once __DIR__ . '/db.php';

/* ---------- 查询快捷方法 ---------- */
/** 多行 */
function q(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

/** 单行 */
function one(string $sql, array $params = []): ?array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}

/** 单值 */
function qv(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $v = $st->fetchColumn();
    return $v === false ? null : $v;
}

/** 写入并返回自增ID */
function qi(string $sql, array $params = []): int
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return (int)db()->lastInsertId();
}

/* ---------- 配置 ---------- */
function cfg(string $key, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (q('SELECT name, value FROM config') as $r) {
            $cache[(string)$r['name']] = $r['value'];
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function set_cfg(string $key, string $value): void
{
    $st = db()->prepare('INSERT INTO config (name, value) VALUES (?, ?)
        ON DUPLICATE KEY UPDATE value = VALUES(value)');
    $st->execute([$key, $value]);
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return (string)$_SESSION['csrf'];
}

function csrf_check($t): bool
{
    return is_string($t) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t);
}

/* ---------- 输出 ---------- */
function json_out(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function h($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/* ---------- 随机 TOKEN ---------- */
function make_token(string $prefix = 'yk-', int $len = 10): string
{
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123789';
    $max = strlen($chars) - 1;
    for ($t = 0; $t < 20; $t++) {
        $s = '';
        for ($i = 0; $i < $len; $i++) { $s .= $chars[random_int(0, $max)]; }
        $uid = $prefix . $s;
        if (qv('SELECT id FROM mail_accounts WHERE uid = ?', [$uid]) === null) { return $uid; }
    }
    return $prefix . strtoupper(substr(bin2hex(random_bytes(8)), 0, $len + 2));
}

/* LIKE 转义（配合 ESCAPE '!'） */
function like_escape(string $s): string
{
    return str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $s);
}

/* 读取请求入参（兼容 JSON body 与表单） */
function request_in(): array
{
    static $in = null;
    if ($in !== null) { return $in; }
    $raw = file_get_contents('php://input');
    $j = $raw !== '' ? json_decode($raw, true) : null;
    if (is_array($j)) {
        $in = $j;
    } else {
        $in = $_POST;
    }
    return $in;
}

/* 激活卡密：首次激活开始计时，end_time = 当前 + activate_days 天 */
function activate_card(string $token): array
{
    $token = trim($token);
    if ($token === '') { return ['code' => 0, 'msg' => '请输入卡密']; }
    $acc = one('SELECT * FROM mail_accounts WHERE uid = ?', [$token]);
    if (!$acc) { return ['code' => 0, 'msg' => '卡密无效或不存在，请核对后重试']; }
    if (isset($acc['status']) && (int)$acc['status'] === 0) {
        return ['code' => 0, 'msg' => '该卡密已被停用，无法激活，请联系卖家'];
    }
    if (!array_key_exists('activated', $acc)) {
        return ['code' => 0, 'msg' => '系统尚未升级，请联系卖家'];
    }
    if ((int)$acc['activated'] === 1) {
        return ['code' => 2, 'msg' => '该卡密已激活，无需重复激活',
                'start_time' => $acc['start_time'], 'end_time' => $acc['end_time']];
    }
    $days = (int)cfg('activate_days', 30);
    if ($days < 1) { $days = 30; }
    qi('UPDATE mail_accounts SET activated = 1, start_time = NOW(),
        end_time = DATE_ADD(NOW(), INTERVAL ? DAY) WHERE id = ?', [$days, (int)$acc['id']]);
    $now = one('SELECT start_time, end_time FROM mail_accounts WHERE id = ?', [(int)$acc['id']]);
    return ['code' => 1, 'msg' => '卡密激活成功',
            'start_time' => $now['start_time'], 'end_time' => $now['end_time']];
}
