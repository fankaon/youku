<?php
/**
 * 查询验证码：按账号邮箱匹配收信服务器 → POP3 登录 → 读最近邮件 → 提取验证码
 * 收紧版：只尝试 POP 端口（110/995），连接超时短，总耗时可控
 */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/pop3.php';
require_once __DIR__ . '/imap.php';

/* 按域名匹配收信服务器（仅 POP 可用行：端口 110/995，且主机不是 imap） */
function mail_servers_for(string $domain): array
{
    $out = [];
    foreach (q('SELECT * FROM mail_url ORDER BY id') as $r) {
        $bz = strtolower(trim((string)($r['pop_bz'] ?? '')));
        $host = strtolower(trim((string)($r['pop_host'] ?? '')));
        $port = (int)($r['pop_port'] ?? 0);
        if ($bz === '') { continue; }
        if (strpos($host, 'imap') !== false) { continue; }       // POP3 客户端不走 IMAP 行
        if (!in_array($port, [110, 995], true)) { continue; }
        if ($bz === $domain || strpos($domain, $bz) !== false || strpos($bz, $domain) !== false) {
            $out[] = $r;
        }
    }
    return $out;
}

/* 从站点配置读取代理（返回 Pop3 用的代理数组，无则 null） */
function mail_proxy(): ?array
{
    $isProxy = cfg('is_proxy');
    if ($isProxy !== '1') { return null; }
    $type = cfg('proxy_type') === '1' ? 'http' : 'socks5';
    $raw  = (string)(cfg('socks_host') ?: cfg('http_proxy'));
    if ($raw === '') { return null; }
    if (!preg_match('/^(?:socks5|http|https):\/\/([^:]+):(\d+)$/i', $raw, $m)) { return null; }
    return [
        'type' => strtolower($m)[0] === 'http' ? 'http' : 'socks5',
        'host' => $m[1],
        'port' => (int)$m[2],
        'user' => (string)(cfg('socks_user') ?: ''),
        'pass' => (string)(cfg('socks_pass') ?: ''),
    ];
}

/* 由 POP 主机推导 IMAP 主机：pop / pop3 前缀 → imap */
function imap_host_of(string $popHost): string
{
    if (preg_match('/^pop3?\.(.+)$/i', $popHost, $m)) { return 'imap.' . $m[1]; }
    return $popHost;
}

/* 主入口 */
function query_verify_code(string $mail): array
{
    $mail = trim($mail);
    if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        return ['code' => 0, 'msg' => '邮箱格式不正确'];
    }
    $acc = one('SELECT * FROM mail_accounts WHERE mail = ?', [$mail]);
    if (!$acc) {
        return ['code' => 0, 'msg' => '账号不存在，请确认输入的是该卡密的优酷账号'];
    }
    if (isset($acc['status']) && (int)$acc['status'] === 0) {
        return ['code' => 0, 'msg' => '该卡密已被停用'];
    }
    if (isset($acc['activated']) && (int)$acc['activated'] === 0) {
        return ['code' => 0, 'msg' => '卡密未激活，请先激活后再查询'];
    }
    if (!empty($acc['end_time']) && strtotime((string)$acc['end_time']) < time()) {
        return ['code' => 0, 'msg' => '该账号已到期'];
    }
    if (trim((string)$acc['pwd']) === '') {
        return ['code' => 0, 'msg' => '该账号未配置邮箱密码，无法查码'];
    }

    $at = strrpos($mail, '@');
    $domain = strtolower(substr($mail, $at + 1));
    $servers = mail_servers_for($domain);
    if (!$servers) {
        return ['code' => 0, 'msg' => "未配置 {$domain} 的收信服务器"];
    }

    $proxy = mail_proxy();
    $errors = [];
    $sawOld = false;    // 找到过验证码但是旧的
    $sawPwd = false;    // 最近邮件是“改密码”验证码
    $sawBind = false;   // 最近邮件是“改绑/绑定”验证码

    /* 验证码“新鲜”窗口：只接受最近 N 秒内收到的验证码邮件（默认600秒） */
    $window = (int)cfg('code_fresh_seconds', 600);
    if ($window < 60) { $window = 600; }

    /* 从一封邮件里取“登录用、新鲜”验证码；否则返回 '' */
    $pick = function (string $raw) use ($window, &$sawOld, &$sawPwd, &$sawBind) {
        /* 1) 类型过滤：只保留“登录”验证码，改密码 / 改绑直接丢弃 */
        $purpose = mail_purpose_text($raw);
        if (mail_is_password($purpose)) { $sawPwd = true; return ''; }
        if (mail_is_binding($purpose))  { $sawBind = true; return ''; }

        /* 2) 必须含验证码 */
        $code = extract_code($raw);
        if ($code === '') { return ''; }

        /* 3) 新鲜度过滤：旧码丢弃 */
        $dts = mail_date_ts($raw);
        if ($dts !== null) {
            $age = time() - $dts;
            if ($age > $window || $age < -120) { $sawOld = true; return ''; }
        }
        return $code;
    };

    foreach ($servers as $srv) {
        $host = (string)$srv['pop_host'];
        $port = (int)$srv['pop_port'];

        /* ---- 优先走 IMAP（实测 aliyun IMAP 可标准登录，POP 走专有加密） ---- */
        $imapHost = imap_host_of($host);
        $imap = new Imap($imapHost, 993, true, 8);
        if ($imap->ok() && $imap->login($mail, (string)$acc['pwd'])) {
            $total = $imap->select_inbox();
            if ($total > 0) {
                $from = max(1, $total - 9);   // 最近 10 封里找新鲜码
                for ($i = $total; $i >= $from; $i--) {
                    $raw = $imap->message($i);
                    if ($raw === '') { continue; }
                    $code = $pick($raw);
                    if ($code !== '') {
                        $imap->close();
                        return ['code' => 1, 'msg' => "验证码：{$code}（请尽快使用，30分钟内有效）"];
                    }
                }
            }
            $errors[] = 'IMAP未找到新鲜验证码';
            $imap->close();
        } elseif ($imap->ok()) {
            $errors[] = 'IMAP登录失败';
            $imap->close();
        }

        /* ---- 回退 POP3 ---- */
        /* 尝试顺序：配置端口；若为110再补995 SSL；连接超时 6 秒，失败快 */
        $attempts = [];
        $attempts[] = ['host' => $host, 'port' => $port, 'ssl' => $port === 995];
        if ($port === 110) { $attempts[] = ['host' => $host, 'port' => 995, 'ssl' => true]; }

        foreach ($attempts as $a) {
            $pop = new Pop3($a['host'], $a['port'], $a['ssl'], 6, $proxy);
            if (!$pop->ok()) {
                $errors[] = $pop->error;
                continue;
            }
            if (!$pop->login($mail, (string)$acc['pwd'])) {
                $errors[] = $pop->error;
                $pop->close();
                continue;
            }
            $total = $pop->count_msg();
            if ($total <= 0) {
                $errors[] = '邮箱中暂无邮件';
                $pop->close();
                continue;
            }
            /* 从最新一封往前读，最多 10 封，只取新鲜码 */
            $from = max(1, $total - 9);
            for ($i = $total; $i >= $from; $i--) {
                $raw = $pop->retrieve($i);
                if ($raw === '') { continue; }
                $code = $pick($raw);
                if ($code !== '') {
                    $pop->close();
                    return ['code' => 1, 'msg' => "验证码：{$code}（请尽快使用，30分钟内有效）"];
                }
            }
            $errors[] = 'POP未找到新鲜验证码';
            $pop->close();
        }
    }

    if ($sawPwd || $sawBind) {
        $what = $sawPwd ? '修改密码' : '改绑/绑定';
        return ['code' => 0, 'msg' => "最近的验证码邮件是「{$what}」验证码，本站只显示登录验证码。请在优酷【登录页】点击获取登录验证码，等 1-3 分钟收到新邮件后，再点查询。"];
    }
    if ($sawOld) {
        return ['code' => 0, 'msg' => '邮箱里只有旧验证码。请先在优酷【登录页】点击「获取验证码」，等 1-3 分钟收到新邮件后，再点查询。'];
    }
    $show = implode('；', array_slice($errors, 0, 3));
    return ['code' => 0, 'msg' => '未获取到登录验证码：' . $show . '。请先在优酷登录页获取验证码后再查询。'];
}

/* =================================================================
 *  邮件解码 + 验证码提取
 * ================================================================= */

/* 取邮件 Date 头的时间戳（用于判断验证码是否“新鲜”） */
function mail_date_ts(string $raw): ?int
{
    if (preg_match('/^Date:\s*(.+)\s*$/im', $raw, $m)) {
        $t = strtotime(trim($m[1]));
        return $t ? $t : null;
    }
    return null;
}

/* 取用于判断“邮件用途”的文本：解码后的标题 + 正文 */
function mail_purpose_text(string $raw): string
{
    $subj = '';
    if (preg_match('/^Subject:\s*(.+)$/im', $raw, $m)) {
        $subj = decode_words($m[1]);
    }
    return $subj . "\n" . decode_mail($raw);
}

/* 是否为“修改/重置/找回密码”类邮件 */
function mail_is_password(string $text): bool
{
    static $kw = ['修改密码', '更改密码', '变更密码', '重置密码', '找回密码', '密码修改', '设置新密码', '改密', '重设密码'];
    foreach ($kw as $w) {
        if (strpos($text, $w) !== false) { return true; }
    }
    return false;
}

/* 是否为“改绑/换绑/绑定手机或邮箱”类邮件 */
function mail_is_binding(string $text): bool
{
    static $kw = ['改绑', '换绑', '解绑', '更换绑定', '修改绑定', '变更绑定', '绑定手机', '手机绑定',
                  '更换手机', '换绑手机', '绑定邮箱', '邮箱绑定', '更换邮箱', '绑定账号', '账号绑定'];
    foreach ($kw as $w) {
        if (strpos($text, $w) !== false) { return true; }
    }
    return false;
}

/* MIME 编码词解码（=?UTF-8?B?...?=） */
function decode_words(string $s): string
{
    if (strpos($s, '=?') === false) { return $s; }
    return preg_replace_callback('/=\?([^?]+)\?([BbQq])\?([^?]*)\?=/', function ($m) {
        $charset = strtoupper($m[1]);
        $text = $m[2] === 'B' || $m[2] === 'b'
            ? base64_decode($m[3])
            : quoted_printable_decode(str_replace('_', ' ', $m[3]));
        return strtoupper($charset) === 'UTF-8' ? $text : @mb_convert_encoding($text, 'UTF-8', $charset);
    }, $s);
}

/* 解码整封邮件，返回纯文本（UTF-8） */
function decode_mail(string $raw): string
{
    /* 分离头与体 */
    $split = preg_split('/\r?\n\r?\n/', $raw, 2);
    $headers = $split[0];
    $body = $split[1] ?? '';

    $hLower = strtolower($headers);
    $encoding = '7bit';
    $charset = 'UTF-8';
    if (preg_match('/content-transfer-encoding:\s*([a-z0-9]+)/i', $hLower, $m)) { $encoding = strtolower(trim($m[1])); }
    if (preg_match('/charset=["\']?([a-z0-9\-]+)/i', $hLower, $m)) { $charset = strtoupper(trim($m[1])); }

    /* multipart：取所有子部分里像文本的段 */
    if (preg_match('/boundary=["\']?([^"\'\s\r\n]+)/i', $headers, $m)) {
        $boundary = $m[1];
        $text = '';
        foreach (preg_split('/--' . preg_quote($boundary, '/') . '/', $body) as $part) {
            $ps = preg_split('/\r?\n\r?\n/', $part, 2);
            $ph = strtolower($ps[0]);
            $pb = $ps[1] ?? '';
            if (strpos($ph, 'text/') !== false || strpos($ph, 'name=') === false) {
                $text .= "\n" . decode_part($ph, $pb);
            }
        }
        $body = $text;
    } else {
        $body = decode_part($hLower, $body);
    }

    $body = decode_words($body);
    if ($charset !== 'UTF-8') {
        $body = @mb_convert_encoding($body, 'UTF-8', $charset);
    }
    return $body;
}

function decode_part(string $partHeaders, string $partBody): string
{
    $enc = '7bit';
    if (preg_match('/content-transfer-encoding:\s*([a-z0-9]+)/i', $partHeaders, $m)) {
        $enc = strtolower(trim($m[1]));
    }
    if ($enc === 'base64') {
        return (string)base64_decode(preg_replace('/\s+/', '', $partBody));
    }
    if ($enc === 'quoted-printable') {
        return quoted_printable_decode($partBody);
    }
    return $partBody;
}

/* 从邮件原文提取 4-8 位数字验证码 */
function extract_code(string $raw): string
{
    $text = decode_mail($raw);
    /* 先把全角数字转半角 */
    $text = mb_convert_kana($text, 'as', 'UTF-8');

    /* 优先：验证码/校验码 等关键词附近的 4-8 位数字 */
    if (preg_match('/(验证码|校验码|验证代码|动态码|安全码|verification\s*code|security\s*code)[^0-9]{0,20}(\d{4,8})/iu', $text, $m)) {
        return $m[2];
    }
    /* 关键词可能在数字之后 */
    if (preg_match('/(\d{4,8})[^0-9]{0,20}(验证码|校验码)/u', $text, $m)) {
        return $m[1];
    }
    /* 兜底：4-8 位独立数字（取第一个） */
    if (preg_match('/(?<!\d)(\d{4,8})(?!\d)/', $text, $m)) {
        return $m[1];
    }
    return '';
}
