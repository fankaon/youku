<?php
/**
 * POP3 客户端（纯 PHP，支持 SSL；可选 SOCKS5 / HTTP 代理）
 * 连接超时短、失败快，避免前端长时间卡住
 */
class Pop3
{
    public string $error = '';
    /** @var resource|null */
    private $fp = null;
    private int $timeout;

    /**
     * @param array|null $proxy ['type'=>'socks5'|'http','host'=>,'port'=>,'user'=>,'pass'=>]
     */
    public function __construct(string $host, int $port, bool $ssl = false, int $timeout = 6, ?array $proxy = null)
    {
        $this->timeout = $timeout;
        $this->error = '';
        $fp = null;

        try {
            if ($proxy) {
                $fp = $this->connect_proxy($proxy, $host, $port, $ssl);
            } else {
                $target = ($ssl ? 'ssl://' : '') . $host;
                $fp = @stream_socket_client("{$target}:{$port}", $eno, $estr, $timeout);
            }
        } catch (Throwable $e) {
            $this->error = '连接异常';
            return;
        }

        if (!$fp) {
            $this->error = "连接失败 {$host}:{$port}";
            return;
        }
        stream_set_timeout($fp, $this->timeout);
        $banner = $this->read_line($fp);
        if ($banner === null || strpos($banner, '+OK') !== 0) {
            $this->error = '服务器无响应';
            fclose($fp);
            return;
        }
        $this->fp = $fp;
    }

    public function ok(): bool { return $this->fp !== null; }

    public function login(string $user, string $pass): bool
    {
        if (!$this->fp) { return false; }
        if (!$this->cmd('USER ' . $user)) { $this->error = '账号被拒'; return false; }
        if (!$this->cmd('PASS ' . $pass)) { $this->error = '邮箱密码错误或未开启POP3'; return false; }
        return true;
    }

    /** 返回邮件总数 */
    public function count_msg(): int
    {
        if (!$this->fp) { return 0; }
        $line = $this->cmd_raw('STAT');
        if ($line && preg_match('/\+OK\s+(\d+)/', $line, $m)) { return (int)$m[1]; }
        return 0;
    }

    /** 取第 i 封邮件原文（i 从 1 开始） */
    public function retrieve(int $i): string
    {
        if (!$this->fp) { return ''; }
        fwrite($this->fp, "RETR {$i}\r\n");
        $head = $this->read_line($this->fp);
        if ($head === null || strpos($head, '+OK') !== 0) { return ''; }
        $out = '';
        while (!feof($this->fp)) {
            $l = fgets($this->fp);
            if ($l === false) { break; }
            if (rtrim($l, "\r\n") === '.') { break; }
            $out .= $l;
        }
        return $out;
    }

    public function close(): void
    {
        if ($this->fp) {
            @fwrite($this->fp, "QUIT\r\n");
            @fclose($this->fp);
            $this->fp = null;
        }
    }

    /* ---------------- 内部 ---------------- */
    private function cmd(string $c): bool
    {
        $line = $this->cmd_raw($c);
        return $line !== null && strpos($line, '+OK') === 0;
    }

    private function cmd_raw(string $c): ?string
    {
        if (!$this->fp) { return null; }
        fwrite($this->fp, $c . "\r\n");
        return $this->read_line($this->fp);
    }

    /** @param resource $fp */
    private function read_line($fp): ?string
    {
        $l = fgets($fp);
        return $l === false ? null : rtrim($l, "\r\n");
    }

    /** 经代理建立到目标的隧道连接 */
    private function connect_proxy(array $proxy, string $host, int $port, bool $ssl)
    {
        $p = @stream_socket_client("{$proxy['host']}:{$proxy['port']}", $eno, $estr, $this->timeout);
        if (!$p) { $this->error = '代理连接失败'; return null; }
        stream_set_timeout($p, $this->timeout);

        if ($proxy['type'] === 'socks5') {
            $auth = !empty($proxy['user']);
            fwrite($p, "\x05\x01" . ($auth ? "\x02" : "\x00"));
            $r = fread($p, 2);
            if ($r === "\x05\x02" && $auth) {
                $u = $proxy['user']; $pw = (string)$proxy['pass'];
                fwrite($p, chr(strlen($u)) . $u . chr(strlen($pw)) . $pw);
                fread($p, 2);
            }
            fwrite($p, "\x05\x01\x00\x03" . chr(strlen($host)) . $host . pack('n', $port));
            $rep = fread($p, 10);
            if (!$rep || ord($rep[1]) !== 0) { fclose($p); $this->error = 'SOCKS5握手失败'; return null; }
        } else {
            $auth = !empty($proxy['user']) ? 'Authorization: Basic ' . base64_encode($proxy['user'] . ':' . $proxy['pass']) . "\r\n" : '';
            fwrite($p, "CONNECT {$host}:{$port} HTTP/1.1\r\nHost: {$host}:{$port}\r\n{$auth}\r\n");
            $r = fgets($p);
            if (!preg_match('/ 200 /', $r)) { fclose($p); $this->error = 'HTTP代理失败'; return null; }
            while (!feof($p)) { if (rtrim(fgets($p), "\r\n") === '') { break; } }
        }

        if ($ssl) {
            if (!stream_socket_enable_crypto($p, true, ['verify_peer' => false, 'verify_peer_name' => false])) {
                fclose($p); $this->error = 'SSL握手失败'; return null;
            }
        }
        return $p;
    }
}
