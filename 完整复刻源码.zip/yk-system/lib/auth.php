<?php
/**
 * 鉴权：管理员登录态、密码哈希、登录/退出
 */
require_once __DIR__ . '/functions.php';

/* 密码哈希：sha256(盐 + 密码) */
function hash_password(string $plain): string
{
    return hash('sha256', PWD_SALT . $plain);
}

function verify_password(string $plain, string $hash): bool
{
    return hash_equals($hash, hash_password($plain));
}

/* 当前登录管理员 */
function current_admin(): ?array
{
    if (empty($_SESSION['admin_id'])) { return null; }
    $row = one('SELECT * FROM admin WHERE id = ?', [(int)$_SESSION['admin_id']]);
    if (!$row || (int)($row['status'] ?? 1) !== 1) { return null; }
    return $row;
}

/* 要求登录，否则跳转/401；返回当前管理员 */
function require_login(): array
{
    $me = current_admin();
    if ($me) { return $me; }
    if (strpos((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''), 'XMLHttpRequest') !== false
        || strpos((string)($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json') !== false
        || strpos((string)($_SERVER['REQUEST_URI'] ?? ''), 'ajax.php') !== false) {
        json_out(['code' => 401, 'msg' => '登录已过期，请重新登录'], 401);
    }
    header('Location: login.php');
    exit;
}

/* 登录校验 */
function do_login(string $username, string $password): array
{
    $row = one('SELECT * FROM admin WHERE username = ?', [$username]);
    if (!$row) { return ['code' => 0, 'msg' => '用户名或密码错误']; }
    if ((int)($row['status'] ?? 1) !== 1) { return ['code' => 0, 'msg' => '该账号已被禁用']; }
    if (!verify_password($password, (string)$row['password'])) {
        return ['code' => 0, 'msg' => '用户名或密码错误'];
    }
    session_regenerate_id(true);
    $_SESSION['admin_id'] = (int)$row['id'];

    db()->prepare('UPDATE admin SET last_time = ?, last_ip = ? WHERE id = ?')
        ->execute([date('Y-m-d H:i:s'), (string)($_SERVER['REMOTE_ADDR'] ?? ''), (int)$row['id']]);
    return ['code' => 1, 'msg' => '登录成功'];
}

function do_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
