<?php
/**
 * 站点配置（由 install.php 自动生成；手动部署可复制本文件为 config.php 并修改）
 */
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'yk_system');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_CHARSET', 'utf8mb4');

/* 密码哈希盐值（安装后请勿修改，否则旧密码失效） */
define('PWD_SALT', 'YkS2026Salt1688');

/* 会话 */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/functions.php';
