<?php
/**
 * 卡密激活页（前端）
 *  GET  /activate.php?token=xxxx   可预填卡密
 *  POST action=activate&token=xxx  返回 JSON
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/functions.php';

/* ---------- POST：激活 ---------- */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['action']) && $_POST['action'] === 'activate') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(activate_card((string)($_POST['token'] ?? '')), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- GET：页面 ---------- */
$token = trim((string)($_GET['token'] ?? ''));
$siteName = cfg('web_title', '验证查询系统');
$notice = cfg('web_notice', '');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>卡密激活 - <?= h($siteName) ?></title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/layui.css">
<script src="/js/jquery.min.js"></script>
<script src="/js/layui.js"></script>
<style>
  body { background: #f0f2f5; }
  .card-box { max-width: 520px; margin: 46px auto; background: #fff; border-radius: 10px;
              box-shadow: 0 4px 20px rgba(0,0,0,.08); padding: 32px 34px; }
  .field { margin-bottom: 18px; }
  .field input { height: 48px; font-size: 15px; letter-spacing: .5px; }
  #result { margin-top: 16px; font-size: 14px; min-height: 22px; }
  @media (max-width: 500px) { .card-box { margin: 16px; padding: 22px; } }
</style>
</head>
<body>
<div class="card-box">
    <h3 class="text-center" style="margin-bottom:8px">卡密激活</h3>
    <p class="text-center" style="color:#999;font-size:13px;margin-bottom:24px">
        输入购买到的卡密，激活后开始计算有效期
    </p>

    <div class="field">
        <input type="text" id="token" class="form-control" placeholder="请输入卡密（yk- 开头）"
               value="<?= h($token) ?>" autocomplete="off">
    </div>
    <button id="actBtn" class="btn btn-primary btn-block" style="height:46px;font-size:16px">立即激活</button>

    <div id="result"></div>

    <?php if ($notice !== ''): ?>
        <div style="background:#fff8e6;border:1px solid #ffe1a8;color:#8a6d3b;font-size:13px;
                    border-radius:6px;padding:10px 12px;margin-top:8px"><?= nl2br(h($notice)) ?></div>
    <?php endif; ?>

    <div class="text-center" style="margin-top:22px;font-size:13px">
        <a href="/" style="color:#666">返回查询首页</a>
    </div>
</div>

<script>
layui.use(['layer'], function () {
    var layer = layui.layer;
    var loading = false;

    function doActivate() {
        if (loading) { return; }
        var token = $.trim($('#token').val());
        if (!token) { layer.msg('请输入卡密', {icon: 5}); return; }
        loading = true;
        var btn = $('#actBtn'); btn.attr('disabled', true).text('正在激活…');
        $('#result').css('color', '#888').text('正在验证卡密，请稍候…');

        $.ajax({
            type: 'POST', url: '/activate.php',
            data: {action: 'activate', token: token},
            dataType: 'json', timeout: 30000,
            success: function (res) {
                if (res.code === 1 || res.code === 2) {
                    var html = '<div style="background:#eafaf0;border:1px solid #b7e4c7;border-radius:8px;padding:14px 16px">'
                        + '<div style="color:#2b8a3e;font-weight:bold;margin-bottom:8px">' + res.msg + '</div>'
                        + '<div style="color:#555;font-size:13px;line-height:1.9">'
                        + '激活时间：' + (res.start_time || '-') + '<br>'
                        + '到期时间：' + (res.end_time || '-')
                        + '</div></div>'
                        + '<a class="btn btn-success btn-block" style="margin-top:14px;height:44px;line-height:30px" href="/?token='
                        + encodeURIComponent(token) + '">进入使用 / 查询验证码</a>';
                    $('#result').css('color', '#2b8a3e').html(html);
                } else {
                    $('#result').css('color', '#c0392b').text(res.msg || '激活失败');
                }
            },
            error: function () { $('#result').css('color', '#c0392b').text('网络异常，请重试'); },
            complete: function () { loading = false; btn.attr('disabled', false).text('立即激活'); }
        });
    }

    $('#actBtn').on('click', doActivate);
    $('#token').on('keydown', function (ev) { if (ev.keyCode === 13) { doActivate(); } });
});
</script>
</body>
</html>
