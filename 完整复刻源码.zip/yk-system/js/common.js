/* ============================================
 * 验证查询系统 · 公共JS
 * ============================================ */

/* 从页面 meta 读取 CSRF token */
var CSRF = '';
(function () {
    var m = document.querySelector('meta[name="csrf"]');
    if (m) CSRF = m.getAttribute('content');
})();

/* HTML 转义 */
function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* 时间格式化（兼容 Y-m-d H:i:s 与 ISO） */
function is_time(t) {
    if (!t || t === '0000-00-00 00:00:00') return '';
    if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(t)) {
        return t.replace('T', ' ');
    }
    var d = new Date(t);
    if (isNaN(d.getTime())) return t;
    function p(n) { return n < 10 ? '0' + n : '' + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate())
        + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

/* 同步 AJAX（兼容旧式调用） */
function jxhucAjax(url, type, data) {
    var res = null;
    $.ajax({
        async: false, type: type, url: url, data: data, dataType: 'json',
        success: function (msg) { res = msg; }
    });
    return res;
}

/* 异步 JSON POST（自动附带 CSRF） */
var http = {
    post: function (url, data) {
        if (CSRF) data = Object.assign({csrf: CSRF}, data);
        return fetch(url, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(data)
        }).then(function (r) {
            return r.json();
        });
    }
};

/* 前端图片弹窗（不依赖 layui） */
function showimg(src) {
    var img = new Image();
    img.onload = function () {
        var maxH = Math.max(200, (window.innerHeight || document.documentElement.clientHeight) - 120);
        var maxW = Math.max(200, (window.innerWidth || document.documentElement.clientWidth) - 80);
        var rate = Math.min(1, maxH / img.height, maxW / img.width);
        var w = Math.round(img.width * rate), h = Math.round(img.height * rate);
        var mask = document.createElement('div');
        mask.id = 'imgMask';
        mask.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.6);z-index:9999;display:flex;align-items:center;justify-content:center;cursor:zoom-out';
        mask.innerHTML = '<img src="' + src + '" style="max-width:96%;max-height:94%;border-radius:6px">';
        mask.onclick = function () { document.body.removeChild(mask); };
        document.body.appendChild(mask);
    };
    img.src = src;
}
