<?php
/**
 * 安装向导：环境检测 → 建库建表 → 写 config.php
 * 安装完成后请删除本文件
 */
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);

$step = isset($_POST['submit']) ? 2 : 1;
$err = '';
$result = null;

/* 环境检测 */
$checks = [
    'PHP 版本 >= 7.2' => version_compare(PHP_VERSION, '7.2.0', '>='),
    'PDO MySQL 扩展' => extension_loaded('pdo_mysql'),
    'cURL 扩展(同步用)' => extension_loaded('curl'),
    'OpenSSL 扩展(SSL查码)' => extension_loaded('openssl'),
];

if ($step === 2) {
    $dbHost = trim($_POST['db_host']);
    $dbPort = trim($_POST['db_port']);
    $dbName = trim($_POST['db_name']);
    $dbUser = trim($_POST['db_user']);
    $dbPass = (string)$_POST['db_pass'];
    $au = trim($_POST['admin_user'] ?: 'admin');
    $ap = (string)($_POST['admin_pass'] ?: 'admin123');

    if (!preg_match('/^[a-zA-Z0-9_]{3,32}$/', $dbName)) {
        $err = '数据库名只能含字母、数字、下划线';
    } elseif (strlen($ap) < 6) {
        $err = '管理员密码至少 6 位';
    } else {
        try {
            /* 连接服务器（不指定库），创建数据库 */
            $pdo = new PDO("mysql:host={$dbHost};port={$dbPort};charset=utf8mb4", $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            ]);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
            $pdo->exec("USE `{$dbName}`");

            /* 执行 install.sql */
            $sql = file_get_contents(__DIR__ . '/install.sql');
            /* 去掉注释行，按分号拆分 */
            $sql = preg_replace('/^--.*$/m', '', $sql);
            foreach (array_filter(array_map('trim', explode(';', $sql))) as $st) {
                if ($st !== '') { $pdo->exec($st); }
            }

            /* 自定义管理员 */
            $salt = 'YkS2026Salt1688';
            $hash = hash('sha256', $salt . $ap);
            $pdo->prepare('UPDATE admin SET username=?, password=? WHERE id=1')
                ->execute([$au, $hash]);

            /* 写 config.php */
            $tpl = file_get_contents(__DIR__ . '/config.sample.php');
            $map = [
                "/define\('DB_HOST', '[^']*'\);/" => "define('DB_HOST', '{$dbHost}');",
                "/define\('DB_PORT', '[^']*'\);/" => "define('DB_PORT', '{$dbPort}');",
                "/define\('DB_NAME', '[^']*'\);/" => "define('DB_NAME', '{$dbName}');",
                "/define\('DB_USER', '[^']*'\);/" => "define('DB_USER', '{$dbUser}');",
                "/define\('DB_PASS', '[^']*'\);/" => "define('DB_PASS', " . var_export($dbPass, true) . ");",
            ];
            foreach ($map as $rgx => $rep) { $tpl = preg_replace($rgx, $rep, $tpl); }
            file_put_contents(__DIR__ . '/config.php', $tpl);

            $result = ['admin' => $au];
        } catch (Throwable $e) {
            $err = '安装失败：' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>安装向导</title>
<link rel="stylesheet" href="/css/bootstrap.min.css">
<style>
  body { background:#2f3a45; }
  .box { max-width:560px; margin:5% auto; background:#fff; border-radius:10px; padding:32px 36px;
         box-shadow:0 8px 30px rgba(0,0,0,.25); }
  .ok { color:#2b8a3e } .no { color:#c0392b }
</style>
</head>
<body>
<div class="box">
<h3 style="margin-bottom:22px">验证查询系统 · 安装向导</h3>

<?php if ($result): ?>
  <div class="alert alert-success">
    安装成功！管理员账号：<b><?= htmlspecialchars($result['admin']) ?></b>
  </div>
  <p>请立即删除服务器上的 <b>install.php</b> 和 <b>config.sample.php</b>（config.php 保留）。</p>
  <a href="/admin/login.php" class="btn btn-primary btn-block">进入后台登录</a>

<?php else: ?>
  <h5>一、环境检测</h5>
  <ul class="list-unstyled" style="font-size:14px;margin-bottom:18px">
    <?php foreach ($checks as $name => $pass): ?>
      <li><?= $pass ? '<span class="ok">✔</span>' : '<span class="no">✘</span>' ?> <?= htmlspecialchars($name) ?></li>
    <?php endforeach; ?>
  </ul>

  <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <h5>二、数据库配置</h5>
  <form method="post">
    <div class="row">
      <div class="col-sm-8"><div class="form-group"><label>数据库主机</label><input class="form-control" name="db_host" value="127.0.0.1" required></div></div>
      <div class="col-sm-4"><div class="form-group"><label>端口</label><input class="form-control" name="db_port" value="3306" required></div></div>
    </div>
    <div class="form-group"><label>数据库名</label><input class="form-control" name="db_name" value="yk_system" required></div>
    <div class="row">
      <div class="col-sm-6"><div class="form-group"><label>数据库用户</label><input class="form-control" name="db_user" value="root" required></div></div>
      <div class="col-sm-6"><div class="form-group"><label>数据库密码</label><input class="form-control" name="db_pass" type="password"></div></div>
    </div>

    <h5 style="margin-top:6px">三、后台管理员</h5>
    <div class="row">
      <div class="col-sm-6"><div class="form-group"><label>管理员用户名</label><input class="form-control" name="admin_user" value="admin"></div></div>
      <div class="col-sm-6"><div class="form-group"><label>管理员密码</label><input class="form-control" name="admin_pass" placeholder="至少6位"></div></div>
    </div>

    <button type="submit" name="submit" class="btn btn-primary btn-block">立即安装</button>
  </form>
<?php endif; ?>
</div>
</body>
</html>
