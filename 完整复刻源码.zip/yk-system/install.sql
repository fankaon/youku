-- =================================================================
--  验证查询系统 · 数据库结构与初始数据
--  字符集 utf8mb4
-- =================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------- 管理员 ----------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` VARCHAR(128) NOT NULL DEFAULT '' COMMENT '密码哈希',
  `role_id` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '角色ID',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1正常 0禁用',
  `add_time` DATETIME NULL DEFAULT NULL,
  `last_time` DATETIME NULL DEFAULT NULL,
  `last_ip` VARCHAR(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员';

-- ---------- 角色 ----------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '角色名称',
  `rules` TEXT NULL COMMENT '权限ID逗号分隔，*为全部',
  `add_time` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色';

-- ---------- 权限 ----------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '父级ID',
  `name` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '名称',
  `url` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '页面文件',
  `icon` VARCHAR(50) NOT NULL DEFAULT '',
  `sort` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限菜单';

-- ---------- 账号 ----------
DROP TABLE IF EXISTS `mail_accounts`;
CREATE TABLE `mail_accounts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'TOKEN(本地随机)',
  `mail` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '优酷账号(邮箱)',
  `yk_pwd` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '优酷密码',
  `pwd` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '邮箱密码',
  `add_time` DATETIME NULL DEFAULT NULL COMMENT '导入时间',
  `start_time` DATETIME NULL DEFAULT NULL COMMENT '激活时间',
  `end_time` DATETIME NULL DEFAULT NULL COMMENT '结束时间',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1正常 0封禁',
  `activated` TINYINT NOT NULL DEFAULT 0 COMMENT '0未激活 1已激活',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid` (`uid`),
  UNIQUE KEY `uk_mail` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='账号';

-- ---------- 收信服务器 ----------
DROP TABLE IF EXISTS `mail_url`;
CREATE TABLE `mail_url` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `pop_host` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '服务器',
  `pop_port` INT NOT NULL DEFAULT 110 COMMENT '端口',
  `pop_bz` VARCHAR(80) NOT NULL DEFAULT '' COMMENT '适用域名',
  `add_time` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收信服务器';

-- ---------- 配置 ----------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(60) NOT NULL DEFAULT '',
  `value` TEXT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='配置';

-- =================================================================
--  初始数据
-- =================================================================

-- 角色：超级管理员
INSERT INTO `roles` (`id`,`name`,`rules`,`add_time`) VALUES
(1,'超级管理员','*', NOW());

-- 管理员：admin / admin123
INSERT INTO `admin` (`id`,`username`,`password`,`role_id`,`status`,`add_time`) VALUES
(1,'admin','642c6239ca3bf9af943cd38a52e128d8e6e5b6622d2f1a2ed5bea34738b17449',1,1,NOW());

-- 权限菜单
INSERT INTO `permissions` (`id`,`pid`,`name`,`url`,`icon`,`sort`) VALUES
(1,0,'账号管理','','',1),
(2,1,'账号列表','mail.php','',1),
(3,1,'批量导入','mail_add.php','',2),
(4,1,'查询地址','mail_url.php','',3),
(5,0,'权限管理','','',2),
(6,5,'角色管理','rules.php','',1),
(7,5,'管理员管理','manage.php','',2),
(8,0,'系统设置','','',3),
(9,8,'系统配置','config.php','',1),
(10,8,'修改密码','uppwd.php','',2);

-- 收信服务器
INSERT INTO `mail_url` (`pop_host`,`pop_port`,`pop_bz`,`add_time`) VALUES
('pop3.aliyun.com',110,'aliyun.com',NOW()),
('pop.163.com',110,'163.com',NOW()),
('pop.126.com',110,'126.com',NOW()),
('pop.qq.com',110,'qq.com',NOW()),
('pop.sina.com',110,'sina.com',NOW());

-- 配置
INSERT INTO `config` (`name`,`value`) VALUES
('web_title','验证查询系统'),
('web_notice',''),
('is_proxy','0'),
('proxy_type','0'),
('socks_host',''),
('socks_user',''),
('socks_pass',''),
('http_proxy',''),
('tutorial_video',''),
('tutorial_image',''),
('activate_days','30'),
('code_fresh_seconds','600');

SET FOREIGN_KEY_CHECKS = 1;
