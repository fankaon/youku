<?php
/**
 * =====================================================================
 *  自动同步：cs.jxhuc.com 后台账号数据 → 本地 mail_accounts 表
 *  策略：100 条/页逐页抓取（最稳），只抓「指定日期起」的新账号；
 *        只取【账号邮箱 / 优酷密码 / 邮箱密码】，TOKEN 一律在本地随机生成，
 *        绝不使用上游 token。按邮箱去重。
 * =====================================================================
 *  用法（在站点根目录下）：
 *      php tools/sync_jxhuc.php                 # 抓今天的新账号（新号随机token，历史保留）
 *      php tools/sync_jxhuc.php --wipe          # 清空本地表后重抓，所有 token 全部重新随机
 *      php tools/sync_jxhuc.php --since=2026-10-06   # 抓指定日期起（默认今天）
 *      php tools/sync_jxhuc.php --prefix=yk-    # token 前缀（默认 yk-）
 *      php tools/sync_jxhuc.php --len=10        # token 随机部分长度（默认10）
 *      php tools/sync_jxhuc.php --dry           # 只抓取不写库（测试用）
 *
 *  数据接口：POST https://cs.jxhuc.com/ajax/
 *      {"contents":"mail","act":"page","first":偏移,"limit":100,"key":""}
 * =====================================================================
 */

require __DIR__ . '/../config.php';

/* ---------------- 参数 ---------------- */
$opt = [
    'wipe'   => false,
    'dry'    => false,
    'since'  => date('Y-m-d'),
    'page'   => 100,
    'sleep'  => 2,
    'prefix' => 'yk-',
    'len'    => 10,
    'source' => 'https://cs.jxhuc.com/ajax/',
];
foreach (array_slice($argv, 1) as $a) {
    if ($a === '--wipe') { $opt['wipe'] = true; }
    elseif ($a === '--dry') { $opt['dry'] = true; }
    elseif (preg_match('/^--since=(\d{4}-\d{2}-\d{2})$/', $a, $m)) { $opt['since'] = $m[1]; }
    elseif (preg_match('/^--page=(\d+)$/', $a, $m)) { $opt['page'] = max(50, (int)$m[1]); }
    elseif (preg_match('/^--sleep=(\d+)$/', $a, $m)) { $opt['sleep'] = (int)$m[1]; }
    elseif (preg_match('/^--prefix=(.*)$/', $a, $m)) { $opt['prefix'] = $m[1]; }
    elseif (preg_match('/^--len=(\d+)$/', $a, $m)) { $opt['len'] = max(4, (int)$m[1]); }
}
$cutoff = strtotime($opt['since'] . ' 00:00:00');
if ($cutoff === false) { slog('起始日期格式错误'); exit(1); }

/* ---------------- 日志 ---------------- */
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) { @mkdir($logDir, 0755, true); }
$logFile = $logDir . '/sync_' . date('Ymd') . '.log';
function slog(string $m) {
    global $logFile;
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $m;
    echo $line, "\n";
    @file_put_contents($logFile, $line . "\n", FILE_APPEND);
}

/* ---------------- 随机 TOKEN 生成 ---------------- */
function gen_token(string $prefix, int $len, array $used): string {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $max = strlen($chars) - 1;
    for ($t = 0; $t < 20; $t++) {
        $s = '';
        for ($i = 0; $i < $len; $i++) { $s .= $chars[random_int(0, $max)]; }
        $uid = $prefix . $s;
        if (!isset($used[$uid])) { return $uid; }
    }
    /* 极小概率撞号，加长一位兜底 */
    return $prefix . substr(strtoupper(bin2hex(random_bytes(8))), 0, $len + 2);
}

/* ---------------- 抓取一页（带重试） ---------------- */
function fetch_page(string $url, int $first, int $limit, int $retries = 4): ?array {
    $payload = json_encode([
        'contents' => 'mail',
        'act'      => 'page',
        'first'    => $first,
        'limit'    => $limit,
        'key'      => '',
    ]);
    /* 上游对连续请求较敏感，失败后退避 3/6/9/12 秒重试 */
    $backoff = [3, 6, 9, 12];
    for ($i = 1; $i <= $retries; $i++) {
        $resp = null;
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $payload,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 120,
                CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
            ]);
            $resp = curl_exec($ch);
            $err  = curl_error($ch);
            curl_close($ch);
            if ($resp === false) { slog("  第{$i}次请求失败: {$err}"); }
        } else {
            $ctx = stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  => "Content-Type: application/json\r\n",
                    'content' => $payload,
                    'timeout' => 120,
                ],
                'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
            ]);
            $resp = @file_get_contents($url, false, $ctx);
            if ($resp === false) { slog("  第{$i}次请求失败"); }
        }
        $j = $resp !== null ? json_decode($resp, true) : null;
        if (is_array($j) && (int)($j['code'] ?? 0) === 1) {
            return $j;
        }
        if ($i < $retries) {
            $wait = $backoff[$i - 1] ?? 12;
            slog("  第 {$i} 次未成功，{$wait} 秒后重试");
            sleep($wait);
        }
    }
    return null;
}

/* ISO8601 时间 → MySQL datetime */
function to_dt($s): ?string {
    if (!$s) { return null; }
    $t = strtotime((string)$s);
    return $t ? date('Y-m-d H:i:s', $t) : null;
}

/* ---------------- 连接本地数据库 ---------------- */
try {
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Throwable $e) {
    slog('数据库连接失败：' . $e->getMessage());
    exit(1);
}

/* 幂等保障：尝试给 mail / uid 加唯一索引（已存在则忽略） */
foreach (['mail' => 'uk_mail', 'uid' => 'uk_uid'] as $col => $idx) {
    try {
        $pdo->exec("ALTER TABLE `mail_accounts` ADD UNIQUE KEY `{$idx}` (`{$col}`)");
    } catch (Throwable $e) { /* 已存在或有重复，忽略 */ }
}

/* ---------------- 逐页抓取（只取 since 起的新账号） ---------------- */
slog("开始同步：起始日期 {$opt['since']}，每页 {$opt['page']} 条，token 前缀「{$opt['prefix']}」，数据源 {$opt['source']}");
$first = 0;
$total = null;
$rows  = [];
$crossed = false;
while (true) {
    $j = fetch_page($opt['source'], $first, $opt['page']);
    if ($j === null) {
        slog("抓取失败，first={$first}，已终止（本地数据未改动）");
        exit(1);
    }
    $total = (int)$j['count'];
    $data  = is_array($j['data'] ?? null) ? $j['data'] : [];

    $pageKept = 0;
    foreach ($data as $r) {
        if (empty($r['mail'])) { continue; }
        $ts = !empty($r['add_time']) ? strtotime((string)$r['add_time']) : false;
        if ($ts !== false && $ts < $cutoff) {
            $crossed = true;       // 已遇到更早的记录
            continue;
        }
        $rows[] = $r;
        $pageKept++;
    }
    slog("抓取 first={$first}，本页 " . count($data) . " 条，符合日期 {$pageKept} 条，累计 " . count($rows));
    $first += count($data);

    if ($crossed) { break; }                          // 已越过起始日期，停止
    if (count($data) === 0 || $first >= $total) { break; }
    sleep($opt['sleep']);
}
slog("抓取完成，起始日期以来共 " . count($rows) . " 条（上游全量 {$total} 条）");

if ($opt['dry']) {
    slog('--dry 模式，不写入数据库');
    exit(0);
}

/* ---------------- 写入本地库 ---------------- */
$pdo->beginTransaction();

if ($opt['wipe']) {
    $pdo->exec('TRUNCATE TABLE `mail_accounts`');
    slog('已清空本地账号表');
}

/* 按邮箱建立现有账号索引（邮箱相同 → 保留原 token，仅更新资料） */
$mailMap = [];
$usedUid = [];
foreach ($pdo->query('SELECT id, uid, mail FROM mail_accounts') as $m) {
    $mailMap[(string)$m['mail']] = (int)$m['id'];
    $usedUid[(string)$m['uid']] = true;
}

$ins = $pdo->prepare(
    'INSERT INTO mail_accounts (uid, mail, yk_pwd, pwd, add_time, end_time) VALUES (?, ?, ?, ?, ?, ?)'
);
$upd = $pdo->prepare(
    'UPDATE mail_accounts SET yk_pwd = ?, pwd = ?, end_time = ? WHERE id = ?'
);

$nIns = $nUpd = 0;
$now = date('Y-m-d H:i:s');
foreach ($rows as $r) {
    $mail = (string)$r['mail'];
    $yk   = (string)($r['yk_pwd'] ?? '');
    $pw   = (string)($r['pwd'] ?? '');
    $end  = to_dt($r['end_time'] ?? null);

    if (isset($mailMap[$mail])) {
        /* 邮箱已存在：保留 token，只更新密码与到期 */
        $upd->execute([$yk, $pw, $end, $mailMap[$mail]]);
        $nUpd++;
    } else {
        /* 新邮箱：本地随机生成 token，绝不沿用上游 uid */
        $uid = gen_token($opt['prefix'], $opt['len'], $usedUid);
        $usedUid[$uid] = true;
        $ins->execute([$uid, $mail, $yk, $pw, $now, $end]);
        $nIns++;
    }
}
$pdo->commit();

slog("同步完成：新增 {$nIns} 条（全新随机token），更新 {$nUpd} 条（保留token），本地现有 " . ($nIns + count($mailMap)) . " 条");
